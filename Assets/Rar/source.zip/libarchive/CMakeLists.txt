#
cmake_minimum_required(VERSION 3.17 FATAL_ERROR)

PROJECT(libarchive C)
#
# Include standard installation directories
include(GNUInstallDirs)
#
SET(CMAKE_MODULE_PATH "${CMAKE_CURRENT_SOURCE_DIR}/build/cmake")
if(NOT CMAKE_RUNTIME_OUTPUT_DIRECTORY)
  set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${libarchive_BINARY_DIR}/bin)
endif()
#
# Set the Build type for make based generators.
# You can choose following types:
#   Debug          : Debug build
#   Release        : Release build
#   RelWithDebInfo : Release build with Debug Info
#   MinSizeRel     : Release Min Size build
#   None           : No build type
IF(NOT CMAKE_BUILD_TYPE)
  SET(CMAKE_BUILD_TYPE "Release" CACHE STRING "Build Type" FORCE)
ENDIF(NOT CMAKE_BUILD_TYPE)
# Set a value type to properly display CMAKE_BUILD_TYPE on GUI if the
# value type is "UNINITIALIZED".
GET_PROPERTY(cached_type CACHE CMAKE_BUILD_TYPE PROPERTY TYPE)
IF("${cached_type}" STREQUAL "UNINITIALIZED")
  SET(CMAKE_BUILD_TYPE "${CMAKE_BUILD_TYPE}" CACHE STRING "Build Type" FORCE)
ENDIF("${cached_type}" STREQUAL "UNINITIALIZED")
# Check the Build Type.
# Convert the CMAKE_BUILD_TYPE to uppercase to perform a case-insensitive comparison.
string(TOUPPER "${CMAKE_BUILD_TYPE}" CMAKE_BUILD_TYPE_UPPER)
IF(NOT "${CMAKE_BUILD_TYPE_UPPER}"
       MATCHES "^(DEBUG|RELEASE|RELWITHDEBINFO|MINSIZEREL|NONE)\$")
  MESSAGE(FATAL_ERROR
          "Unknown keyword for CMAKE_BUILD_TYPE: ${CMAKE_BUILD_TYPE}\n"
          "Acceptable keywords: Debug, Release, RelWithDebInfo, MinSizeRel, None")
ENDIF(NOT "${CMAKE_BUILD_TYPE_UPPER}"
       MATCHES "^(DEBUG|RELEASE|RELWITHDEBINFO|MINSIZEREL|NONE)\$")

# On MacOS, prefer MacPorts libraries to system libraries.
# I haven't come up with a compelling argument for this to be conditional.
list(APPEND CMAKE_PREFIX_PATH /opt/local)
# Enable @rpath in the install name.
# detail in "cmake  --help-policy CMP0042"
SET(CMAKE_MACOSX_RPATH ON)

#
# Version - read from 'version' file.
#
FILE(STRINGS ${CMAKE_CURRENT_SOURCE_DIR}/build/version _version)
STRING(REGEX REPLACE
 "^([0-9])[0-9][0-9][0-9][0-9][0-9][0-9][a-z]*$" "\\1" _major ${_version})
STRING(REGEX REPLACE
 "^[0-9]([0-9][0-9][0-9])[0-9][0-9][0-9][a-z]*$" "\\1" _minor ${_version})
STRING(REGEX REPLACE
 "^[0-9][0-9][0-9][0-9]([0-9][0-9][0-9])[a-z]*$" "\\1" _revision ${_version})
STRING(REGEX REPLACE
 "^[0-9][0-9][0-9][0-9][0-9][0-9][0-9]([a-z]*)$" "\\1" _quality ${_version})
SET(_version_number ${_major}${_minor}${_revision})
STRING(REGEX REPLACE "[0]*([^0]*[0-9])$" "\\1" _trimmed_minor ${_minor})
STRING(REGEX REPLACE "[0]*([^0]*[0-9])$" "\\1" _trimmed_revision ${_revision})
#
SET(VERSION                    "${_major}.${_trimmed_minor}.${_trimmed_revision}${_quality}")
SET(BSDCPIO_VERSION_STRING     "${VERSION}")
SET(BSDTAR_VERSION_STRING      "${VERSION}")
SET(BSDCAT_VERSION_STRING      "${VERSION}")
SET(BSDUNZIP_VERSION_STRING    "${VERSION}")
SET(LIBARCHIVE_VERSION_NUMBER  "${_version_number}")
SET(LIBARCHIVE_VERSION_STRING  "${VERSION}")

# INTERFACE_VERSION increments with every release
# libarchive 2.7 == interface version 9 = 2 + 7
# libarchive 2.8 == interface version 10 = 2 + 8
# libarchive 2.9 == interface version 11 = 2 + 9
# libarchive 3.0 == interface version 12
# libarchive 3.1 == interface version 13
math(EXPR INTERFACE_VERSION  "13 + ${_minor}")

# Set SOVERSION so it matches libtool's conventions
# libtool accepts a string "current:revision:age"; in libarchive, that's set to
# - current: ${INTERFACE_VERSION} = 13 + ${_minor}
# - revision: ${_revision}
# - age: ${_minor}
# Since libtool computes SOVERSION as "current - age", it's just '13' again
math(EXPR SOVERSION "${INTERFACE_VERSION} - ${_minor}")
set(SOVERSION_FULL "${SOVERSION}.${_trimmed_minor}.${_trimmed_revision}")

# Override CMake's default shared library versioning scheme, which uses SOVERSION and VERSION,
# to match libtool's conventions (see https://github.com/mesonbuild/meson/issues/1451)
# - compatibility version: current + 1 = ${INTERFACE_VERSION} + 1
# - current version: ${current + 1}.${revision}
math(EXPR MACHO_COMPATIBILITY_VERSION "${INTERFACE_VERSION} + 1")
set(MACHO_CURRENT_VERSION "${MACHO_COMPATIBILITY_VERSION}.${_revision}")

# Enable CMAKE_PUSH_CHECK_STATE() and CMAKE_POP_CHECK_STATE() macros
# saving and restoring the state of the variables.
INCLUDE(CMakePushCheckState)

# Enable the pkg-config helpers.
INCLUDE(FindPkgConfig)

# Initialize the state of the variables. This initialization is not
# necessary but this shows you what value the variables initially have.
SET(CMAKE_REQUIRED_DEFINITIONS)
SET(CMAKE_REQUIRED_INCLUDES)
SET(CMAKE_REQUIRED_LIBRARIES)
SET(CMAKE_REQUIRED_FLAGS)
if (CMAKE_BUILD_TYPE STREQUAL "Debug")
  OPTION(ENABLE_WERROR "Treat warnings as errors - default is ON for Debug, OFF otherwise." ON)
else ()
  OPTION(ENABLE_WERROR "Treat warnings as errors - default is ON for Debug, OFF otherwise." OFF)
endif ()

# Especially for early development, we want to be a little
# aggressive about diagnosing build problems; this can get
# relaxed somewhat in final shipping versions.
IF (CMAKE_C_COMPILER_ID MATCHES "^GNU$" OR
    CMAKE_C_COMPILER_ID MATCHES "^Clang$" AND NOT MSVC)
  SET(CMAKE_REQUIRED_FLAGS "-Wall -Wformat -Wformat-security")
  #################################################################
  # Set compile flags for all build types.
  SET(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -Wall -Wformat -Wformat-security")
  if (ENABLE_WERROR)
    SET(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -Werror")
  endif ()
  #################################################################
  # Set compile flags for debug build.
  # This is added into CMAKE_C_FLAGS when CMAKE_BUILD_TYPE is "Debug"
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -g")
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -Wextra")
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -Wunused")
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -Wshadow")
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -Wmissing-prototypes")
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -Wcast-qual")
  # Ideally this will be a compile/link time check, yet there's no obvious way
  # how considering how old our minimum required cmake version is. The official
  # cmake.org side does not host the manual pages even. Normally we can use
  # either of the following two, yet neither is supported as of 3.0.2
  # - check_linker_flag - does not exist
  # - try_compile - does not support linker flags
  IF(CMAKE_SYSTEM_NAME MATCHES "Darwin")
    SET(CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} -Wl,-dead_strip")
    SET(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} -Wl,-dead_strip")
  ELSEIF(CMAKE_SYSTEM_NAME MATCHES "SunOS")
    # SunOS linker doesn't support --gc-sections
  ELSE()
    # Place the functions and data into separate sections, allowing the linker
    # to garbage collect the unused ones.
    SET(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -ffunction-sections -fdata-sections")
    SET(CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} -Wl,--gc-sections")
    SET(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} -Wl,--gc-sections")
    # Printing the discarded section is "too much", so enable on demand.
    #SET(CMAKE_EXE_LINKER_FLAGS_DEBUG "${CMAKE_EXE_LINKER_FLAGS_DEBUG} -Wl,--print-gc-sections")
    #SET(CMAKE_SHARED_LINKER_FLAGS_DEBUG "${CMAKE_SHARED_LINKER_FLAGS_DEBUG} -Wl,--print-gc-sections")
  ENDIF()
ENDIF (CMAKE_C_COMPILER_ID MATCHES "^GNU$" OR
       CMAKE_C_COMPILER_ID MATCHES "^Clang$" AND NOT MSVC)
IF (CMAKE_C_COMPILER_ID MATCHES "^XL$")
  SET(CMAKE_C_COMPILER "xlc_r")
  SET(CMAKE_REQUIRED_FLAGS "-qflag=e:e -qformat=sec")
  #################################################################
  # Set compile flags for all build types.
  SET(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -qflag=e:e -qformat=sec")
  if (ENABLE_WERROR)
    SET(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -qhalt=w")
  endif ()
  #################################################################
  # Set compile flags for debug build.
  # This is added into CMAKE_C_FLAGS when CMAKE_BUILD_TYPE is "Debug"
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -g")
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -qflag=w:w")
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -qinfo=pro:use")
ENDIF(CMAKE_C_COMPILER_ID MATCHES "^XL$")
IF (MSVC)
  if (ENABLE_WERROR)
    # /WX option is the same as gcc's -Werror option.
    SET(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} /WX")
  endif ()
  #################################################################
  # Set compile flags for debug build.
  # This is added into CMAKE_C_FLAGS when CMAKE_BUILD_TYPE is "Debug"
  # Enable level 4 C4062: The enumerate has no associated handler in a switch
  #                       statement and there is no default that can catch it.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14062")
  # Enable level 4 C4254: A larger bit field was assigned to a smaller bit
  #                       field.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14254")
  # Enable level 4 C4295: An array was initialized but the last character in
  #                       the array is not a null; accessing the array may
  #                       produce unexpected results.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14295")
  # Enable level 4 C4296: An unsigned variable was used in a comparison
  #                       operation with zero.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14296")
  # Enable level 4 C4389: An operation involved signed and unsigned variables.
  #                       This could result in a loss of data.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14389")
  # Enable level 4 C4505: The given function is local and not referenced in
  #                       the body of the module; therefore, the function is
  #                       dead code.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14505")
  # Enable level 4 C4514: The optimizer removed an inline function that is not
  #                       called.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14514")
  # Enable level 4 C4702: Unreachable code.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14702")
  # Enable level 4 C4706: The test value in a conditional expression was the
  #                       result of an assignment.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /w14706")
  # /Oi option enables built-in functions.
  SET(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} /Oi")
  #################################################################
  # Set compile flags for release build.
  SET(CMAKE_C_FLAGS_RELEASE "${CMAKE_C_FLAGS_RELEASE} /Oi")
ENDIF (MSVC)

# Enable CTest/CDash support
include(CTest)

option(BUILD_SHARED_LIBS "Build shared libraries" ON)

OPTION(ENABLE_MBEDTLS "Enable use of mbed TLS" OFF)
OPTION(ENABLE_NETTLE "Enable use of Nettle" OFF)
OPTION(ENABLE_OPENSSL "Enable use of OpenSSL" ON)
OPTION(ENABLE_MD "Enable use of Message Digest" ON)
OPTION(ENABLE_LIBB2 "Enable the use of the system LIBB2 library if found" ON)
OPTION(ENABLE_LZ4 "Enable the use of the system LZ4 library if found" ON)
OPTION(ENABLE_LZO "Enable the use of the system LZO library if found" OFF)
OPTION(ENABLE_LZMA "Enable the use of the system LZMA library if found" ON)
OPTION(ENABLE_ZSTD "Enable the use of the system zstd library if found" ON)

OPTION(ENABLE_ZLIB "Enable the use of the system ZLIB library if found" ON)
OPTION(ENABLE_BZip2 "Enable the use of the system BZip2 library if found" ON)
OPTION(ENABLE_LIBXML2 "Enable the use of the system libxml2 library if found" ON)
OPTION(ENABLE_BSDXML "Enable the use of the system bsdxml library if found" ON)
OPTION(ENABLE_EXPAT "Enable the use of the system EXPAT library if found" ON)
OPTION(ENABLE_WIN32_XMLLITE "Enable the use of the Windows XmlLite library if found" ON)
OPTION(ENABLE_PCREPOSIX "Enable the use of the system PCREPOSIX library if found" ON)
OPTION(ENABLE_PCRE2POSIX "Enable the use of the system PCRE2POSIX library if found" ON)
OPTION(ENABLE_LIBGCC "Enable the use of the system LibGCC library if found" ON)
# CNG is used for encrypt/decrypt Zip archives on Windows.
OPTION(ENABLE_CNG "Enable the use of Windows CNG (Crypto Next Generation) if found" ON)

OPTION(ENABLE_TAR "Enable tar building" ON)
OPTION(ENABLE_TAR_SHARED "Enable dynamic build of tar" FALSE)
OPTION(ENABLE_CPIO "Enable cpio building" ON)
OPTION(ENABLE_CPIO_SHARED "Enable dynamic build of cpio" FALSE)
OPTION(ENABLE_CAT "Enable cat building" ON)
OPTION(ENABLE_CAT_SHARED "Enable dynamic build of cat" FALSE)
OPTION(ENABLE_UNZIP "Enable unzip building" ON)
OPTION(ENABLE_UNZIP_SHARED "Enable dynamic build of unzip" FALSE)
OPTION(ENABLE_XATTR "Enable extended attribute support" ON)
OPTION(ENABLE_ACL "Enable ACL support" ON)
OPTION(ENABLE_ICONV "Enable iconv support" ON)
OPTION(ENABLE_TEST "Enable unit and regression tests" ON)
OPTION(ENABLE_COVERAGE "Enable code coverage (GCC only, automatically sets ENABLE_TEST to ON)" FALSE)
OPTION(ENABLE_INSTALL "Enable installing of libraries" ON)
OPTION(ENABLE_CLANG_TIDY "Enable custom build-time code health checks" OFF)

IF(WIN32 AND MSVC)
  OPTION(MSVC_USE_STATIC_CRT "Use static CRT" OFF)
ENDIF()

SET(POSIX_REGEX_LIB "AUTO" CACHE STRING "Choose what library should provide POSIX regular expression support")
SET(ENABLE_SAFESEH "AUTO" CACHE STRING "Enable use of /SAFESEH linker flag (MSVC only)")
SET(WINDOWS_VERSION "WIN10" CACHE STRING "Set Windows version to use (Windows only)")

IF(ENABLE_COVERAGE)
	include(LibarchiveCodeCoverage)
ENDIF(ENABLE_COVERAGE)

IF(ENABLE_TEST)
	ENABLE_TESTING()
ENDIF(ENABLE_TEST)

IF(WIN32)
  IF(WINDOWS_VERSION STREQUAL "WIN10")
    SET(NTDDI_VERSION 0x0A000000)
    SET(_WIN32_WINNT 0x0A00)
    SET(WINVER 0x0A00)
  ELSEIF(WINDOWS_VERSION STREQUAL "WIN8")
    SET(NTDDI_VERSION 0x06020000)
    SET(_WIN32_WINNT 0x0602)
    SET(WINVER 0x0602)
  ELSEIF(WINDOWS_VERSION STREQUAL "WIN7")
    SET(NTDDI_VERSION 0x06010000)
    SET(_WIN32_WINNT 0x0601)
    SET(WINVER 0x0601)
  ELSEIF(WINDOWS_VERSION STREQUAL "WS08")
    SET(NTDDI_VERSION 0x06000100)
    SET(_WIN32_WINNT 0x0600)
    SET(WINVER 0x0600)
  ELSE(WINDOWS_VERSION STREQUAL "WIN10")
    # Default to Windows Server 2003 API if we don't recognize the specifier
    SET(NTDDI_VERSION 0x05020000)
    SET(_WIN32_WINNT 0x0502)
    SET(WINVER 0x0502)
  ENDIF(WINDOWS_VERSION STREQUAL "WIN10")
ENDIF(WIN32)

IF(MSVC)
  IF(ENABLE_SAFESEH STREQUAL "YES")
    SET(CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} /SAFESEH")
    SET(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} /SAFESEH")
    SET(CMAKE_MODULE_LINKER_FLAGS "${CMAKE_MODULE_LINKER_FLAGS} /SAFESEH")
    SET(ENV{LDFLAGS} "$ENV{LDFLAGS} /SAFESEH")
  ELSEIF(ENABLE_SAFESEH STREQUAL "NO")
    SET(CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} /SAFESEH:NO")
    SET(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} /SAFESEH:NO")
    SET(CMAKE_MODULE_LINKER_FLAGS "${CMAKE_MODULE_LINKER_FLAGS} /SAFESEH:NO")
    SET(ENV{LDFLAGS} "$ENV{LDFLAGS} /SAFESEH:NO")
  ENDIF(ENABLE_SAFESEH STREQUAL "YES")
ENDIF(MSVC)

IF("${CMAKE_C_PLATFORM_ID}" MATCHES "^(HP-UX)$")
  ADD_DEFINITIONS(-D_XOPEN_SOURCE=500) # Ask wchar.h for mbstate_t
ENDIF()

IF(MINGW)
  ADD_DEFINITIONS(-D__USE_MINGW_ANSI_STDIO=1)
  ADD_DEFINITIONS(-D__MINGW_USE_VC2005_COMPAT=1)
ENDIF()

#
INCLUDE(CheckCSourceCompiles)
INCLUDE(CheckCSourceRuns)
INCLUDE(CheckFileOffsetBits)
INCLUDE(CheckFuncs)
INCLUDE(CheckHeaderDirent)
INCLUDE(CheckIncludeFile)
INCLUDE(CheckIncludeFiles)
INCLUDE(CheckLibraryExists)
INCLUDE(CheckStructHasMember)
INCLUDE(CheckSymbolExists)
INCLUDE(CheckTypeExists)
INCLUDE(CheckTypeSize)

#
# Generate list.h
#
MACRO (GENERATE_LIST_H _listfile _cmlist _target __list_sources)
  SET(_argv ${ARGV})
  # Remove _listfile, _cmlist, and _target from _argv
  LIST(REMOVE_AT _argv 0 1 2)
  # Convert source paths to absolute so discover_tests.cmake can find them
  # regardless of the working directory when cmake -P runs.
  SET(_gl_abs_sources "")
  FOREACH(_gl_src ${_argv})
    IF(IS_ABSOLUTE "${_gl_src}")
      LIST(APPEND _gl_abs_sources "${_gl_src}")
    ELSE()
      LIST(APPEND _gl_abs_sources "${CMAKE_CURRENT_SOURCE_DIR}/${_gl_src}")
    ENDIF()
  ENDFOREACH()
  # Stamp out discover_tests.cmake with source list and output path baked in.
  SET(SOURCES "${_gl_abs_sources}")
  SET(OUTPUT "${_listfile}")
  CONFIGURE_FILE(
    ${CMAKE_SOURCE_DIR}/build/cmake/discover_tests.cmake.in
    ${CMAKE_CURRENT_BINARY_DIR}/discover_tests.cmake
    @ONLY)
  UNSET(SOURCES)
  UNSET(OUTPUT)
  # list.h is regenerated at build time whenever any test .c file changes.
  ADD_CUSTOM_COMMAND(
    OUTPUT "${_listfile}"
    COMMAND ${CMAKE_COMMAND} -P ${CMAKE_CURRENT_BINARY_DIR}/discover_tests.cmake
    DEPENDS ${_gl_abs_sources}
    COMMENT "Generating ${_listfile}"
    VERBATIM)
  # Attaching list.h to the target tells CMake to build it before compiling.
  TARGET_SOURCES(${_target} PRIVATE "${_listfile}")
ENDMACRO (GENERATE_LIST_H)

#
# Register individual tests with CTest by scanning DEFINE_TEST() declarations.
#
MACRO (DISCOVER_TESTS _component __list_sources)
  IF(ENABLE_TEST)
    SET(_sources ${ARGV})
    LIST(REMOVE_AT _sources 0)
    FOREACH (_src ${_sources})
      IF (_src MATCHES "test_[^/]+\\.c$")
        FILE(STRINGS "${_src}" _lines REGEX "^DEFINE_TEST\(.*\)")
        FOREACH (_line ${_lines})
          STRING(REGEX MATCH "DEFINE_TEST\((.*)\)" _full_match ${_line})
          # CMake REGEX seems to handle ( and \( rather inconsistently...
          # So we go through an extra dance to definitively strip the parens
          STRING(REPLACE "(" "" _test_name_with_paren "${CMAKE_MATCH_1}")
          STRING(REPLACE ")" "" _test_name "${_test_name_with_paren}")
          SET(_full_test_name "${_component}_${_test_name}")
          ADD_TEST(NAME ${_full_test_name}
                   COMMAND ${_component}_test -vv
                                   -r ${CMAKE_CURRENT_SOURCE_DIR}
                                   -s
                                   ${_test_name})
          SET_TESTS_PROPERTIES(${_full_test_name} PROPERTIES SKIP_RETURN_CODE 2)
        ENDFOREACH (_line)
      ENDIF (_src MATCHES "test_[^/]+\\.c$")
    ENDFOREACH (_src)
  ENDIF(ENABLE_TEST)
ENDMACRO (DISCOVER_TESTS __list_sources)

#
# Generate installation rules for man pages.
#
MACRO (INSTALL_MAN __mans)
  IF(ENABLE_INSTALL)
    FOREACH (_man ${ARGV})
      STRING(REGEX REPLACE "^.+[.]([1-9])" "\\1" _mansect ${_man})
      INSTALL(FILES ${_man} DESTINATION "share/man/man${_mansect}")
    ENDFOREACH (_man)
  ENDIF(ENABLE_INSTALL)
ENDMACRO (INSTALL_MAN __mans)
#
# Find out what macro is needed to use libraries on Windows.
#
MACRO (TRY_MACRO_FOR_LIBRARY INCLUDES LIBRARIES
       TRY_TYPE SAMPLE_SOURCE MACRO_LIST)
  IF(WIN32 AND NOT CYGWIN)
    CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
    SET(CMAKE_REQUIRED_INCLUDES ${INCLUDES})
    SET(CMAKE_REQUIRED_LIBRARIES ${LIBRARIES})
    FOREACH(VAR ${MACRO_LIST})
      # Clear ${VAR} from CACHE If the libraries which ${VAR} was
      # checked with are changed.
      SET(VAR_WITH_LIB "${VAR}_WITH_LIB")
      GET_PROPERTY(PREV_VAR_WITH_LIB VARIABLE PROPERTY ${VAR_WITH_LIB})
      IF(NOT "${PREV_VAR_WITH_LIB}" STREQUAL "${LIBRARIES}")
        UNSET(${VAR} CACHE)
      ENDIF(NOT "${PREV_VAR_WITH_LIB}" STREQUAL "${LIBRARIES}")
      # Check if the library can be used with the macro.
      IF("${TRY_TYPE}" MATCHES "COMPILES")
        CHECK_C_SOURCE_COMPILES("${SAMPLE_SOURCE}" ${VAR})
      ELSEIF("${TRY_TYPE}" MATCHES "RUNS")
        IF(CMAKE_CROSSCOMPILING)
          MESSAGE(WARNING "Cannot test run \"${VAR}\" when cross-compiling")
        ELSE(CMAKE_CROSSCOMPILING)
          CHECK_C_SOURCE_RUNS("${SAMPLE_SOURCE}" ${VAR})
        ENDIF(CMAKE_CROSSCOMPILING)
      ELSE("${TRY_TYPE}" MATCHES "COMPILES")
        MESSAGE(FATAL_ERROR "UNKNOWN KEYWORD \"${TRY_TYPE}\" FOR TRY_TYPE")
      ENDIF("${TRY_TYPE}" MATCHES "COMPILES")
      # Save the libraries which ${VAR} is checked with.
      SET(${VAR_WITH_LIB} "${LIBRARIES}" CACHE INTERNAL
          "Macro ${VAR} is checked with")
    ENDFOREACH(VAR)
    CMAKE_POP_CHECK_STATE()	# Restore the state of the variables
  ENDIF(WIN32 AND NOT CYGWIN)
ENDMACRO (TRY_MACRO_FOR_LIBRARY)
#
# Check compress/decompress libraries
#
IF(WIN32 AND NOT CMAKE_CL_64 AND NOT CYGWIN)
  # GnuWin32 is only for Win32, not Win64.
  SET(__GNUWIN32PATH "C:/Program Files/GnuWin32")
ENDIF(WIN32 AND NOT CMAKE_CL_64 AND NOT CYGWIN)
IF(DEFINED __GNUWIN32PATH AND EXISTS "${__GNUWIN32PATH}")
  # You have to add a path available DLL file into PATH environment variable.
  # Maybe DLL path is "C:/Program Files/GnuWin32/bin".
  # The zlib and the bzip2 Setup program have installed programs and DLLs into
  # "C:/Program Files/GnuWin32" by default.
  # This is convenience setting for Windows.
  SET(CMAKE_PREFIX_PATH ${__GNUWIN32PATH} $(CMAKE_PREFIX_PATH))
  #
  # If you didn't use Setup program or installed into nonstandard path,
  # cmake cannot find out your zlib or bzip2 libraries and include files,
  # you should execute cmake with  -DCMAKE_PREFIX_PATH option.
  #   e.g.
  #     cmake -DCMAKE_PREFIX_PATH=<your-GnuWin32-path> <path-to-source>
  #
  # If compiling error occurred in zconf.h, You may need patch to zconf.h.
  #--- zconf.h.orig	2005-07-21 00:40:26.000000000
  #+++ zconf.h	2009-01-19 11:39:10.093750000
  #@@ -286,7 +286,7 @@
  #
  # #if 1           /* HAVE_UNISTD_H -- this line is updated by ./configure */
  # #  include <sys/types.h> /* for off_t */
  #-#  include <unistd.h>    /* for SEEK_* and off_t */
  #+#  include <stdio.h>    /* for SEEK_* and off_t */
  # #  ifdef VMS
  # #    include <unixio.h>   /* for off_t */
  # #  endif
ENDIF(DEFINED __GNUWIN32PATH AND EXISTS "${__GNUWIN32PATH}")

SET(ADDITIONAL_LIBS "")
#
# Find ZLIB
#
IF(ENABLE_ZLIB)
  # Require zlib >= 1.2.1, see: https://github.com/libarchive/libarchive/issues/615
  # zlib 1.2.0 should also work, but it is difficult to test for. Let's require
  # zlib >= 1.2.1 for consistency with the autoconf build.
  FIND_PACKAGE(ZLIB 1.2.1)
ELSE()
  SET(ZLIB_FOUND FALSE) # Override cached value
ENDIF()
IF(ZLIB_FOUND)
  SET(HAVE_LIBZ 1)
  SET(HAVE_ZLIB_H 1)
  INCLUDE_DIRECTORIES(${ZLIB_INCLUDE_DIR})
  LIST(APPEND ADDITIONAL_LIBS ${ZLIB_LIBRARIES})
  IF(WIN32 AND NOT CYGWIN)
    #
    # Test if ZLIB_WINAPI macro is needed to use.
    #
    TRY_MACRO_FOR_LIBRARY(
      "${ZLIB_INCLUDE_DIR}" "${ZLIB_LIBRARIES}"
      RUNS
      "#include <zlib.h>\nint main() {uLong f = zlibCompileFlags(); return (f&(1U<<10))?0:-1; }"
      ZLIB_WINAPI)
    IF(ZLIB_WINAPI)
      ADD_DEFINITIONS(-DZLIB_WINAPI)
    ELSE(ZLIB_WINAPI)
      # Test if a macro is needed for the library.
      TRY_MACRO_FOR_LIBRARY(
        "${ZLIB_INCLUDE_DIR}" "${ZLIB_LIBRARIES}"
        COMPILES
        "#include <zlib.h>\nint main() {return zlibVersion()?1:0; }"
        "ZLIB_DLL;WITHOUT_ZLIB_DLL")
      IF(ZLIB_DLL)
        ADD_DEFINITIONS(-DZLIB_DLL)
      ENDIF(ZLIB_DLL)
    ENDIF(ZLIB_WINAPI)
  ENDIF(WIN32 AND NOT CYGWIN)
ENDIF(ZLIB_FOUND)
MARK_AS_ADVANCED(CLEAR ZLIB_INCLUDE_DIR)
MARK_AS_ADVANCED(CLEAR ZLIB_LIBRARY)
#
# Find BZip2
#
IF(ENABLE_BZip2)
  FIND_PACKAGE(BZip2)
ELSE()
  SET(BZIP2_FOUND FALSE) # Override cached value
ENDIF()
IF(BZIP2_FOUND)
  SET(HAVE_LIBBZ2 1)
  SET(HAVE_BZLIB_H 1)
  INCLUDE_DIRECTORIES(${BZIP2_INCLUDE_DIR})
  LIST(APPEND ADDITIONAL_LIBS ${BZIP2_LIBRARIES})
  # Test if a macro is needed for the library.
  TRY_MACRO_FOR_LIBRARY(
    "${BZIP2_INCLUDE_DIR}" "${BZIP2_LIBRARIES}"
    COMPILES
    "#include <bzlib.h>\nint main() {return BZ2_bzlibVersion()?1:0; }"
    "USE_BZIP2_DLL;USE_BZIP2_STATIC")
  IF(USE_BZIP2_DLL)
    ADD_DEFINITIONS(-DUSE_BZIP2_DLL)
  ELSEIF(USE_BZIP2_STATIC)
    ADD_DEFINITIONS(-DUSE_BZIP2_STATIC)
  ENDIF(USE_BZIP2_DLL)
ENDIF(BZIP2_FOUND)
MARK_AS_ADVANCED(CLEAR BZIP2_INCLUDE_DIR)
MARK_AS_ADVANCED(CLEAR BZIP2_LIBRARIES)


#
# Find LZMA
#
IF(ENABLE_LZMA)
  FIND_PACKAGE(LibLZMA)
ELSE()
  SET(LIBLZMA_FOUND FALSE) # Override cached value
ENDIF()

IF(LIBLZMA_FOUND)
  SET(HAVE_LIBLZMA 1)
  SET(HAVE_LZMA_H 1)
  CMAKE_PUSH_CHECK_STATE()
  SET(CMAKE_REQUIRED_INCLUDES ${LIBLZMA_INCLUDE_DIR})
  SET(CMAKE_REQUIRED_LIBRARIES ${LIBLZMA_LIBRARIES})
  INCLUDE_DIRECTORIES(${LIBLZMA_INCLUDE_DIRS})
  LIST(APPEND ADDITIONAL_LIBS ${LIBLZMA_LIBRARIES})
  # Test if a macro is needed for the library.
  TRY_MACRO_FOR_LIBRARY(
    "${LIBLZMA_INCLUDE_DIRS}" "${LIBLZMA_LIBRARIES}"
    COMPILES
    "#include <lzma.h>\nint main() {return (int)lzma_version_number(); }"
    "WITHOUT_LZMA_API_STATIC;LZMA_API_STATIC")
  CHECK_C_SOURCE_COMPILES(
    "#include <lzma.h>\n#if LZMA_VERSION < 50020000\n#error unsupported\n#endif\nint main(void){int ignored __attribute__((unused)); ignored = lzma_stream_encoder_mt(0, 0); return 0;}"
    HAVE_LZMA_STREAM_ENCODER_MT)
  IF(NOT WITHOUT_LZMA_API_STATIC AND LZMA_API_STATIC)
    ADD_DEFINITIONS(-DLZMA_API_STATIC)
  ENDIF(NOT WITHOUT_LZMA_API_STATIC AND LZMA_API_STATIC)
  CMAKE_POP_CHECK_STATE()
ELSE(LIBLZMA_FOUND)
# LZMA not found and will not be used.
  SET(HAVE_LZMA_STREAM_ENCODER_MT 0)
ENDIF(LIBLZMA_FOUND)
MARK_AS_ADVANCED(CLEAR LIBLZMA_INCLUDE_DIR)
MARK_AS_ADVANCED(CLEAR LIBLZMA_LIBRARY)

#
# Find LZO2
#
IF(ENABLE_LZO)
  IF (LZO2_INCLUDE_DIR)
    # Already in cache, be silent
    SET(LZO2_FIND_QUIETLY TRUE)
  ENDIF (LZO2_INCLUDE_DIR)

  FIND_PATH(LZO2_INCLUDE_DIR lzo/lzoconf.h)
  FIND_LIBRARY(LZO2_LIBRARY NAMES lzo2 liblzo2)
  INCLUDE(FindPackageHandleStandardArgs)
  FIND_PACKAGE_HANDLE_STANDARD_ARGS(LZO2 DEFAULT_MSG LZO2_LIBRARY LZO2_INCLUDE_DIR)
ELSE(ENABLE_LZO)
  SET(LZO2_FOUND FALSE) # Override cached value
ENDIF(ENABLE_LZO)
IF(LZO2_FOUND)
  SET(HAVE_LIBLZO2 1)
  SET(HAVE_LZO_LZOCONF_H 1)
  SET(HAVE_LZO_LZO1X_H 1)
  INCLUDE_DIRECTORIES(${LZO2_INCLUDE_DIR})
  LIST(APPEND ADDITIONAL_LIBS ${LZO2_LIBRARY})
  #
  # TODO: test for static library.
  #
ENDIF(LZO2_FOUND)
MARK_AS_ADVANCED(CLEAR LZO2_INCLUDE_DIR)
MARK_AS_ADVANCED(CLEAR LZO2_LIBRARY)
#
# Find libb2
#
IF(ENABLE_LIBB2)
  IF (LIBB2_INCLUDE_DIR)
    # Already in cache, be silent
    SET(LIBB2_FIND_QUIETLY TRUE)
  ENDIF (LIBB2_INCLUDE_DIR)

  FIND_PATH(LIBB2_INCLUDE_DIR blake2.h)
  FIND_LIBRARY(LIBB2_LIBRARY NAMES b2 libb2)
  INCLUDE(FindPackageHandleStandardArgs)
  FIND_PACKAGE_HANDLE_STANDARD_ARGS(LIBB2 DEFAULT_MSG LIBB2_LIBRARY LIBB2_INCLUDE_DIR)
ELSE(ENABLE_LIBB2)
  SET(LIBB2_FOUND FALSE) # Override cached value
  UNSET(LIBB2_PKGCONFIG_VERSION CACHE)
ENDIF(ENABLE_LIBB2)
IF(LIBB2_FOUND)
  SET(HAVE_LIBB2 1)
  SET(HAVE_BLAKE2_H 1)
  SET(ARCHIVE_BLAKE2 FALSE)
  LIST(APPEND ADDITIONAL_LIBS ${LIBB2_LIBRARY})
  INCLUDE_DIRECTORIES(${LIBB2_INCLUDE_DIR})
  CMAKE_PUSH_CHECK_STATE()
  SET(CMAKE_REQUIRED_LIBRARIES ${LIBB2_LIBRARY})
  SET(CMAKE_REQUIRED_INCLUDES ${LIBB2_INCLUDE_DIR})
  CHECK_FUNCTION_EXISTS(blake2sp_init HAVE_LIBB2)
  CMAKE_POP_CHECK_STATE()
  pkg_check_modules(LIBB2 libb2)
  IF(LIBB2_VERSION)
    SET(LIBB2_PKGCONFIG_VERSION LIBB2_VERSION)
  ENDIF(LIBB2_VERSION)
ELSE(LIBB2_FOUND)
  SET(ARCHIVE_BLAKE2 TRUE)
  UNSET(LIBB2_PKGCONFIG_VERSION CACHE)
ENDIF(LIBB2_FOUND)
#
# Find LZ4
#
IF(ENABLE_LZ4)
  IF (LZ4_INCLUDE_DIR)
    # Already in cache, be silent
    SET(LZ4_FIND_QUIETLY TRUE)
  ENDIF (LZ4_INCLUDE_DIR)

  FIND_PATH(LZ4_INCLUDE_DIR lz4.h)
  FIND_LIBRARY(LZ4_LIBRARY NAMES lz4 liblz4)
  INCLUDE(FindPackageHandleStandardArgs)
  FIND_PACKAGE_HANDLE_STANDARD_ARGS(LZ4 DEFAULT_MSG LZ4_LIBRARY LZ4_INCLUDE_DIR)
ELSE(ENABLE_LZ4)
  SET(LZ4_FOUND FALSE) # Override cached value
ENDIF(ENABLE_LZ4)
IF(LZ4_FOUND)
  SET(HAVE_LIBLZ4 1)
  SET(HAVE_LZ4_H 1)
  CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
  SET(CMAKE_REQUIRED_INCLUDES ${LZ4_INCLUDE_DIR})
  CHECK_INCLUDE_FILES("lz4hc.h" HAVE_LZ4HC_H)
  CMAKE_POP_CHECK_STATE()	# Restore the state of the variables
  INCLUDE_DIRECTORIES(${LZ4_INCLUDE_DIR})
  LIST(APPEND ADDITIONAL_LIBS ${LZ4_LIBRARY})
  #
  # TODO: test for static library.
  #
ENDIF(LZ4_FOUND)
MARK_AS_ADVANCED(CLEAR LZ4_INCLUDE_DIR)
MARK_AS_ADVANCED(CLEAR LZ4_LIBRARY)
#
# Find Zstd
#
IF(ENABLE_ZSTD)
  IF (ZSTD_INCLUDE_DIR)
    # Already in cache, be silent
    SET(ZSTD_FIND_QUIETLY TRUE)
  ENDIF (ZSTD_INCLUDE_DIR)

  IF(UNIX)
    FIND_PACKAGE(PkgConfig QUIET)
    PKG_SEARCH_MODULE(PC_ZSTD libzstd)
  ENDIF()

  FIND_PATH(ZSTD_INCLUDE_DIR zstd.h HINTS ${PC_ZSTD_INCLUDEDIR} ${PC_ZSTD_INCLUDE_DIRS})
  FIND_LIBRARY(ZSTD_LIBRARY NAMES zstd libzstd zstd_static HINTS ${PC_ZSTD_LIBDIR} ${PC_ZSTD_LIBRARY_DIRS})
  INCLUDE(FindPackageHandleStandardArgs)
  FIND_PACKAGE_HANDLE_STANDARD_ARGS(ZSTD DEFAULT_MSG ZSTD_LIBRARY ZSTD_INCLUDE_DIR)
ELSE(ENABLE_ZSTD)
  SET(ZSTD_FOUND FALSE) # Override cached value
ENDIF(ENABLE_ZSTD)
IF(ZSTD_FOUND)
  SET(HAVE_ZSTD_H 1)
  INCLUDE_DIRECTORIES(${ZSTD_INCLUDE_DIR})
  LIST(APPEND ADDITIONAL_LIBS ${ZSTD_LIBRARY})
  CMAKE_PUSH_CHECK_STATE()
  SET(CMAKE_REQUIRED_LIBRARIES ${ZSTD_LIBRARY})
  SET(CMAKE_REQUIRED_INCLUDES ${ZSTD_INCLUDE_DIR})
  CHECK_FUNCTION_EXISTS(ZSTD_decompressStream HAVE_LIBZSTD)
  CHECK_FUNCTION_EXISTS(ZSTD_compressStream HAVE_ZSTD_compressStream)
  CHECK_FUNCTION_EXISTS(ZSTD_minCLevel HAVE_ZSTD_minCLevel)
  #
  # TODO: test for static library.
  #
  CMAKE_POP_CHECK_STATE()
ENDIF(ZSTD_FOUND)
MARK_AS_ADVANCED(CLEAR ZSTD_INCLUDE_DIR)
MARK_AS_ADVANCED(CLEAR ZSTD_LIBRARY)

#
# Check headers
#
CHECK_HEADER_DIRENT()

SET(INCLUDES "")
MACRO (LA_CHECK_INCLUDE_FILE header var)
      CHECK_INCLUDE_FILES("${INCLUDES};${header}" ${var})
      IF (${var})
      	 SET(INCLUDES ${INCLUDES} ${header})
      ENDIF (${var})
ENDMACRO (LA_CHECK_INCLUDE_FILE)

# Some FreeBSD headers assume sys/types.h was already included.
LA_CHECK_INCLUDE_FILE("sys/types.h" HAVE_SYS_TYPES_H)

# Alphabetize the rest unless there's a compelling reason
LA_CHECK_INCLUDE_FILE("acl/libacl.h" HAVE_ACL_LIBACL_H)
LA_CHECK_INCLUDE_FILE("attr/xattr.h" HAVE_ATTR_XATTR_H)
LA_CHECK_INCLUDE_FILE("ctype.h" HAVE_CTYPE_H)
LA_CHECK_INCLUDE_FILE("copyfile.h" HAVE_COPYFILE_H)
LA_CHECK_INCLUDE_FILE("direct.h" HAVE_DIRECT_H)
LA_CHECK_INCLUDE_FILE("dlfcn.h" HAVE_DLFCN_H)
LA_CHECK_INCLUDE_FILE("errno.h" HAVE_ERRNO_H)
LA_CHECK_INCLUDE_FILE("ext2fs/ext2_fs.h" HAVE_EXT2FS_EXT2_FS_H)

CHECK_C_SOURCE_COMPILES("#include <sys/ioctl.h>
#include <ext2fs/ext2_fs.h>
int main(void) { return EXT2_IOC_GETFLAGS; }" HAVE_WORKING_EXT2_IOC_GETFLAGS)

LA_CHECK_INCLUDE_FILE("fcntl.h" HAVE_FCNTL_H)
LA_CHECK_INCLUDE_FILE("fnmatch.h" HAVE_FNMATCH_H)
LA_CHECK_INCLUDE_FILE("grp.h" HAVE_GRP_H)
LA_CHECK_INCLUDE_FILE("inttypes.h" HAVE_INTTYPES_H)
LA_CHECK_INCLUDE_FILE("io.h" HAVE_IO_H)
LA_CHECK_INCLUDE_FILE("langinfo.h" HAVE_LANGINFO_H)
LA_CHECK_INCLUDE_FILE("limits.h" HAVE_LIMITS_H)
LA_CHECK_INCLUDE_FILE("linux/types.h" HAVE_LINUX_TYPES_H)
LA_CHECK_INCLUDE_FILE("linux/fiemap.h" HAVE_LINUX_FIEMAP_H)
LA_CHECK_INCLUDE_FILE("linux/fs.h" HAVE_LINUX_FS_H)

CHECK_C_SOURCE_COMPILES("#include <sys/ioctl.h>
#include <linux/fs.h>
int main(void) { return FS_IOC_GETFLAGS; }" HAVE_WORKING_FS_IOC_GETFLAGS)

LA_CHECK_INCLUDE_FILE("intsafe.h" HAVE_INTSAFE_H)
LA_CHECK_INCLUDE_FILE("linux/magic.h" HAVE_LINUX_MAGIC_H)
LA_CHECK_INCLUDE_FILE("locale.h" HAVE_LOCALE_H)
LA_CHECK_INCLUDE_FILE("membership.h" HAVE_MEMBERSHIP_H)
LA_CHECK_INCLUDE_FILE("paths.h" HAVE_PATHS_H)
LA_CHECK_INCLUDE_FILE("poll.h" HAVE_POLL_H)
LA_CHECK_INCLUDE_FILE("process.h" HAVE_PROCESS_H)
LA_CHECK_INCLUDE_FILE("pthread.h" HAVE_PTHREAD_H)
LA_CHECK_INCLUDE_FILE("pwd.h" HAVE_PWD_H)
LA_CHECK_INCLUDE_FILE("readpassphrase.h" HAVE_READPASSPHRASE_H)
LA_CHECK_INCLUDE_FILE("regex.h" HAVE_REGEX_H)
LA_CHECK_INCLUDE_FILE("signal.h" HAVE_SIGNAL_H)
LA_CHECK_INCLUDE_FILE("spawn.h" HAVE_SPAWN_H)
LA_CHECK_INCLUDE_FILE("stdarg.h" HAVE_STDARG_H)
LA_CHECK_INCLUDE_FILE("stdckdint.h" HAVE_STDCKDINT_H)
LA_CHECK_INCLUDE_FILE("stdint.h" HAVE_STDINT_H)
LA_CHECK_INCLUDE_FILE("stdio.h" HAVE_STDIO_H)
LA_CHECK_INCLUDE_FILE("stdlib.h" HAVE_STDLIB_H)
LA_CHECK_INCLUDE_FILE("string.h" HAVE_STRING_H)
LA_CHECK_INCLUDE_FILE("strings.h" HAVE_STRINGS_H)
LA_CHECK_INCLUDE_FILE("sys/acl.h" HAVE_SYS_ACL_H)
LA_CHECK_INCLUDE_FILE("sys/cdefs.h" HAVE_SYS_CDEFS_H)
LA_CHECK_INCLUDE_FILE("sys/extattr.h" HAVE_SYS_EXTATTR_H)
LA_CHECK_INCLUDE_FILE("sys/ioctl.h" HAVE_SYS_IOCTL_H)
LA_CHECK_INCLUDE_FILE("sys/mkdev.h" HAVE_SYS_MKDEV_H)
LA_CHECK_INCLUDE_FILE("sys/mount.h" HAVE_SYS_MOUNT_H)
LA_CHECK_INCLUDE_FILE("sys/param.h" HAVE_SYS_PARAM_H)
LA_CHECK_INCLUDE_FILE("sys/poll.h" HAVE_SYS_POLL_H)
LA_CHECK_INCLUDE_FILE("sys/richacl.h" HAVE_SYS_RICHACL_H)
LA_CHECK_INCLUDE_FILE("sys/select.h" HAVE_SYS_SELECT_H)
LA_CHECK_INCLUDE_FILE("sys/single_threaded.h" HAVE_SYS_SINGLE_THREADED_H)
LA_CHECK_INCLUDE_FILE("sys/stat.h" HAVE_SYS_STAT_H)
LA_CHECK_INCLUDE_FILE("sys/statfs.h" HAVE_SYS_STATFS_H)
LA_CHECK_INCLUDE_FILE("sys/statvfs.h" HAVE_SYS_STATVFS_H)
LA_CHECK_INCLUDE_FILE("sys/sysctl.h" HAVE_SYS_SYSCTL_H)
LA_CHECK_INCLUDE_FILE("sys/sysmacros.h" HAVE_SYS_SYSMACROS_H)
LA_CHECK_INCLUDE_FILE("sys/time.h" HAVE_SYS_TIME_H)
LA_CHECK_INCLUDE_FILE("sys/utime.h" HAVE_SYS_UTIME_H)
LA_CHECK_INCLUDE_FILE("sys/utsname.h" HAVE_SYS_UTSNAME_H)
LA_CHECK_INCLUDE_FILE("sys/vfs.h" HAVE_SYS_VFS_H)
LA_CHECK_INCLUDE_FILE("sys/wait.h" HAVE_SYS_WAIT_H)
LA_CHECK_INCLUDE_FILE("sys/xattr.h" HAVE_SYS_XATTR_H)
LA_CHECK_INCLUDE_FILE("time.h" HAVE_TIME_H)
LA_CHECK_INCLUDE_FILE("unistd.h" HAVE_UNISTD_H)
LA_CHECK_INCLUDE_FILE("utime.h" HAVE_UTIME_H)
LA_CHECK_INCLUDE_FILE("wchar.h" HAVE_WCHAR_H)
LA_CHECK_INCLUDE_FILE("wctype.h" HAVE_WCTYPE_H)
LA_CHECK_INCLUDE_FILE("windows.h" HAVE_WINDOWS_H)
LA_CHECK_INCLUDE_FILE("bcrypt.h" HAVE_BCRYPT_H)
IF(HAVE_BCRYPT_H)
  LIST(APPEND ADDITIONAL_LIBS "bcrypt")
  IF(ENABLE_CNG)
    SET(ARCHIVE_CRYPTO_WIN        1)
    # bcrypt supports these algorithms on all available versions
    SET(ARCHIVE_CRYPTO_MD5        1)
    SET(ARCHIVE_CRYPTO_MD5_WIN    1)
    SET(ARCHIVE_CRYPTO_SHA1       1)
    SET(ARCHIVE_CRYPTO_SHA1_WIN   1)
    SET(ARCHIVE_CRYPTO_SHA256     1)
    SET(ARCHIVE_CRYPTO_SHA256_WIN 1)
    SET(ARCHIVE_CRYPTO_SHA384     1)
    SET(ARCHIVE_CRYPTO_SHA384_WIN 1)
    SET(ARCHIVE_CRYPTO_SHA512     1)
    SET(ARCHIVE_CRYPTO_SHA512_WIN 1)
  ENDIF(ENABLE_CNG)
ENDIF(HAVE_BCRYPT_H)
# Following files need windows.h, so we should test it after windows.h test.
LA_CHECK_INCLUDE_FILE("winioctl.h" HAVE_WINIOCTL_H)

#
# Check whether use of __EXTENSIONS__ is safe.
# We need some macro such as _GNU_SOURCE to use extension functions.
#
SET(_INCLUDE_FILES)
FOREACH (it ${_HEADER})
   SET(_INCLUDE_FILES "${_INCLUDE_FILES}#include <${it}>\n")
ENDFOREACH (it)

CHECK_C_SOURCE_COMPILES(
  "#define __EXTENSIONS__ 1
   ${_INCLUDE_FILES}
   int main() { return 0;}"
 SAFE_TO_DEFINE_EXTENSIONS)

#
# Find mbed TLS
#
IF(ENABLE_MBEDTLS)
  FIND_PACKAGE(MbedTLS)
  IF(MBEDTLS_FOUND)
    SET(HAVE_LIBMBEDCRYPTO 1)
    LIST(APPEND ADDITIONAL_LIBS ${MBEDCRYPTO_LIBRARY})
    INCLUDE_DIRECTORIES(${MBEDTLS_INCLUDE_DIRS})

    CMAKE_PUSH_CHECK_STATE()
    LIST(APPEND CMAKE_REQUIRED_INCLUDES ${MBEDTLS_INCLUDE_DIRS})
    LA_CHECK_INCLUDE_FILE("mbedtls/aes.h" HAVE_MBEDTLS_AES_H)
    LA_CHECK_INCLUDE_FILE("mbedtls/md.h" HAVE_MBEDTLS_MD_H)
    LA_CHECK_INCLUDE_FILE("mbedtls/pkcs5.h" HAVE_MBEDTLS_PKCS5_H)
    LA_CHECK_INCLUDE_FILE("mbedtls/version.h" HAVE_MBEDTLS_VERSION_H)
    CMAKE_POP_CHECK_STATE()

  ENDIF(MBEDTLS_FOUND)
  MARK_AS_ADVANCED(CLEAR MBEDTLS_INCLUDE_DIRS)
  MARK_AS_ADVANCED(CLEAR MBEDCRYPTO_LIBRARY)
ENDIF(ENABLE_MBEDTLS)

#
# Find Nettle
#
IF(ENABLE_NETTLE)
  FIND_PACKAGE(Nettle)
  IF(NETTLE_FOUND)
    SET(HAVE_LIBNETTLE 1)
    LIST(APPEND ADDITIONAL_LIBS ${NETTLE_LIBRARIES})
    INCLUDE_DIRECTORIES(${NETTLE_INCLUDE_DIR})

    CMAKE_PUSH_CHECK_STATE()
    LIST(APPEND CMAKE_REQUIRED_INCLUDES ${NETTLE_INCLUDE_DIR})
    LA_CHECK_INCLUDE_FILE("nettle/aes.h" HAVE_NETTLE_AES_H)
    LA_CHECK_INCLUDE_FILE("nettle/hmac.h" HAVE_NETTLE_HMAC_H)
    LA_CHECK_INCLUDE_FILE("nettle/md5.h" HAVE_NETTLE_MD5_H)
    LA_CHECK_INCLUDE_FILE("nettle/pbkdf2.h" HAVE_NETTLE_PBKDF2_H)
    LA_CHECK_INCLUDE_FILE("nettle/ripemd160.h" HAVE_NETTLE_RIPEMD160_H)
    LA_CHECK_INCLUDE_FILE("nettle/sha.h" HAVE_NETTLE_SHA_H)
    LA_CHECK_INCLUDE_FILE("nettle/sha1.h" HAVE_NETTLE_SHA1_H)
    LA_CHECK_INCLUDE_FILE("nettle/sha2.h" HAVE_NETTLE_SHA2_H)
    LA_CHECK_INCLUDE_FILE("nettle/version.h" HAVE_NETTLE_VERSION_H)
    CMAKE_POP_CHECK_STATE()

  ENDIF(NETTLE_FOUND)
  MARK_AS_ADVANCED(CLEAR NETTLE_INCLUDE_DIR)
  MARK_AS_ADVANCED(CLEAR NETTLE_LIBRARIES)
ENDIF(ENABLE_NETTLE)

#
# Find OpenSSL
# (Except on Mac, where OpenSSL is deprecated.)
#
IF(ENABLE_OPENSSL AND NOT CMAKE_SYSTEM_NAME MATCHES "Darwin")
  FIND_PACKAGE(OpenSSL)
  IF(OPENSSL_FOUND)
    SET(HAVE_LIBCRYPTO 1)
    INCLUDE_DIRECTORIES(${OPENSSL_INCLUDE_DIR})
    LIST(APPEND ADDITIONAL_LIBS ${OPENSSL_CRYPTO_LIBRARY})

    CMAKE_PUSH_CHECK_STATE()
    SET(CMAKE_REQUIRED_LIBRARIES ${OPENSSL_CRYPTO_LIBRARY})
    SET(CMAKE_REQUIRED_INCLUDES ${OPENSSL_INCLUDE_DIR})
    LA_CHECK_INCLUDE_FILE("openssl/evp.h" HAVE_OPENSSL_EVP_H)
    LA_CHECK_INCLUDE_FILE("openssl/opensslv.h" HAVE_OPENSSL_OPENSSLV_H)
    CHECK_FUNCTION_EXISTS(PKCS5_PBKDF2_HMAC_SHA1 HAVE_PKCS5_PBKDF2_HMAC_SHA1)
    CMAKE_POP_CHECK_STATE()

  ENDIF(OPENSSL_FOUND)
ELSE()
  SET(OPENSSL_FOUND FALSE) # Override cached value
ENDIF()

# FreeBSD libmd
IF(ENABLE_MD AND NOT OPENSSL_FOUND)
  CHECK_LIBRARY_EXISTS(md "MD5Init" "" LIBMD_FOUND)
  IF(LIBMD_FOUND)
    CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
    SET(CMAKE_REQUIRED_LIBRARIES "md")
    FIND_LIBRARY(LIBMD_LIBRARY NAMES md)
    LIST(APPEND ADDITIONAL_LIBS ${LIBMD_LIBRARY})
    CMAKE_POP_CHECK_STATE()	# Restore the state of the variables
  ENDIF(LIBMD_FOUND)
ENDIF(ENABLE_MD AND NOT OPENSSL_FOUND)

# libbsd for readpassphrase on Haiku
IF("${CMAKE_SYSTEM_NAME}" MATCHES "Haiku")
  MESSAGE(STATUS "Adding libbsd for Haiku")

  CMAKE_PUSH_CHECK_STATE()
  SET(CMAKE_REQUIRED_LIBRARIES "bsd")
  FIND_LIBRARY(LIBBSD_LIBRARY NAMES bsd)
  LIST(APPEND ADDITIONAL_LIBS ${LIBBSD_LIBRARY})
  CMAKE_POP_CHECK_STATE()

ENDIF("${CMAKE_SYSTEM_NAME}" MATCHES "Haiku")

#
# How to prove that CRYPTO functions, which have several names on various
# platforms, just see if archive_digest.c can compile and link against
# required libraries.
#
MACRO(CHECK_CRYPTO ALGORITHMS IMPLEMENTATION)
    FOREACH(ALGORITHM ${ALGORITHMS})
      IF(NOT ARCHIVE_CRYPTO_${ALGORITHM})
      STRING(TOLOWER "${ALGORITHM}" lower_algorithm)
      STRING(TOUPPER "${ALGORITHM}" algorithm)
      IF ("${IMPLEMENTATION}" MATCHES "^OPENSSL$" AND NOT OPENSSL_FOUND)
        SET(ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION} FALSE)
      ELSEIF("${IMPLEMENTATION}" MATCHES "^MBEDTLS$" AND NOT MBEDTLS_FOUND)
        SET(ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION} FALSE)
      ELSEIF("${IMPLEMENTATION}" MATCHES "^NETTLE$" AND NOT NETTLE_FOUND)
        SET(ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION} FALSE)
      ENDIF("${IMPLEMENTATION}" MATCHES "^OPENSSL$" AND NOT OPENSSL_FOUND)

      IF(NOT DEFINED ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION})
        # Probe the local implementation for whether this
	# crypto implementation is available on this platform.
	SET(TRY_CRYPTO_REQUIRED_INCLUDES
	  "-DINCLUDE_DIRECTORIES:STRING=${CMAKE_BINARY_DIR};${CMAKE_CURRENT_SOURCE_DIR}/libarchive;${CMAKE_BINARY_DIR}${CMAKE_FILES_DIRECTORY}/CMakeTmp")
	SET(TRY_CRYPTO_REQUIRED_LIBS)
	IF ("${IMPLEMENTATION}" MATCHES "^OPENSSL$" AND OPENSSL_FOUND)
	    SET(TRY_CRYPTO_REQUIRED_INCLUDES
	      "${TRY_CRYPTO_REQUIRED_INCLUDES};${OPENSSL_INCLUDE_DIR}")
	    SET(TRY_CRYPTO_REQUIRED_LIBS
	        "-DLINK_LIBRARIES:STRING=${OPENSSL_LIBRARIES}")
	ELSEIF("${IMPLEMENTATION}" MATCHES "^MBEDTLS$" AND MBEDTLS_FOUND)
	    SET(TRY_CRYPTO_REQUIRED_INCLUDES
	      "${TRY_CRYPTO_REQUIRED_INCLUDES};${MBEDTLS_INCLUDE_DIRS}")
	    SET(TRY_CRYPTO_REQUIRED_LIBS
	      "-DLINK_LIBRARIES:STRING=${MBEDCRYPTO_LIBRARY}")
	ELSEIF("${IMPLEMENTATION}" MATCHES "^NETTLE$" AND NETTLE_FOUND)
	    SET(TRY_CRYPTO_REQUIRED_INCLUDES
	      "${TRY_CRYPTO_REQUIRED_INCLUDES};${NETTLE_INCLUDE_DIR}")
	    SET(TRY_CRYPTO_REQUIRED_LIBS
	        "-DLINK_LIBRARIES:STRING=${NETTLE_LIBRARY}")
	ELSEIF("${IMPLEMENTATION}" MATCHES "^LIBMD$" AND LIBMD_FOUND)
	    SET(TRY_CRYPTO_REQUIRED_LIBS
	        "-DLINK_LIBRARIES:STRING=${LIBMD_LIBRARY}")
	ENDIF("${IMPLEMENTATION}" MATCHES "^OPENSSL$" AND OPENSSL_FOUND)

    CONFIGURE_FILE(${CMAKE_CURRENT_SOURCE_DIR}/build/cmake/config.h.in
      ${CMAKE_BINARY_DIR}${CMAKE_FILES_DIRECTORY}/CMakeTmp/confdefs.h)
	FILE(READ "${CMAKE_BINARY_DIR}${CMAKE_FILES_DIRECTORY}/CMakeTmp/confdefs.h"
	     CONFDEFS_H)
	FILE(READ "${CMAKE_CURRENT_SOURCE_DIR}/libarchive/archive_digest.c"
	     ARCHIVE_CRYPTO_C)

	SET(SOURCE "${CONFDEFS_H}

#define ARCHIVE_${algorithm}_COMPILE_TEST
#define ARCHIVE_CRYPTO_${algorithm}_${IMPLEMENTATION}
#define PLATFORM_CONFIG_H \"check_crypto_md.h\"

${ARCHIVE_CRYPTO_C}

int
main(int argc, char **argv)
{
  archive_${lower_algorithm}_ctx ctx;
  archive_${lower_algorithm}_init(&ctx);
  archive_${lower_algorithm}_update(&ctx, *argv, argc);
  archive_${lower_algorithm}_final(&ctx, NULL);
  return 0;
}
")

  FILE(WRITE "${CMAKE_BINARY_DIR}${CMAKE_FILES_DIRECTORY}/CMakeTmp/check_crypto_md.h" "")
	FILE(WRITE "${CMAKE_BINARY_DIR}${CMAKE_FILES_DIRECTORY}/CMakeTmp/check_crypto_md.c" "${SOURCE}")
	MESSAGE(STATUS "Checking support for ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION}")

	TRY_COMPILE(ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION}
	  ${CMAKE_BINARY_DIR}
	  ${CMAKE_BINARY_DIR}${CMAKE_FILES_DIRECTORY}/CMakeTmp/check_crypto_md.c
	  CMAKE_FLAGS
	   "${TRY_CRYPTO_REQUIRED_LIBS}"
	   "${TRY_CRYPTO_REQUIRED_INCLUDES}"
	  OUTPUT_VARIABLE OUTPUT)

	# Inform user whether or not we found it; if not, log why we didn't.
        IF (ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION})
          MESSAGE(STATUS "Checking support for ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION} -- found")
		  SET(ARCHIVE_CRYPTO_${ALGORITHM} 1)
        ELSE (ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION})
          MESSAGE(STATUS "Checking support for ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION} -- not found")
          FILE(APPEND ${CMAKE_BINARY_DIR}${CMAKE_FILES_DIRECTORY}/CMakeOutput.log
    	    "Checking support for ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION} failed with the following output:\n"
    	    "${OUTPUT}\n"
    	    "Source file was:\n${SOURCE}\n")
        ENDIF (ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION})
      ENDIF(NOT DEFINED ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION})

      # Add appropriate libs/includes depending on whether the implementation
      # was found on this platform.
      IF (ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION})
        IF ("${IMPLEMENTATION}" MATCHES "^OPENSSL$" AND OPENSSL_FOUND)
          INCLUDE_DIRECTORIES(${OPENSSL_INCLUDE_DIR})
	  LIST(APPEND ADDITIONAL_LIBS ${OPENSSL_LIBRARIES})
	   LIST(REMOVE_DUPLICATES ADDITIONAL_LIBS)
        ENDIF ("${IMPLEMENTATION}" MATCHES "^OPENSSL$" AND OPENSSL_FOUND)
      ENDIF (ARCHIVE_CRYPTO_${ALGORITHM}_${IMPLEMENTATION})
      ENDIF(NOT ARCHIVE_CRYPTO_${ALGORITHM})
    ENDFOREACH(ALGORITHM ${ALGORITHMS})
ENDMACRO(CHECK_CRYPTO ALGORITHMS IMPLEMENTATION)

#
# Find iconv
# POSIX defines the second arg as const char **
# and requires it to be in libc.  But we can accept
# a non-const argument here and can support iconv()
# being in libiconv.
#
MACRO(CHECK_ICONV LIB TRY_ICONV_CONST)
  IF(NOT HAVE_ICONV)
    CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
    IF (CMAKE_C_COMPILER_ID MATCHES "^GNU$" OR
        CMAKE_C_COMPILER_ID MATCHES "^Clang$")
      #
      # During checking iconv proto type, we should use -Werror to avoid the
      # success of iconv detection with a warning, which would be a false
      # positive.  So this is needed for all build modes, even in release mode.
      #
      SET(CMAKE_REQUIRED_FLAGS "${CMAKE_REQUIRED_FLAGS} -Werror")
    ENDIF (CMAKE_C_COMPILER_ID MATCHES "^GNU$" OR
           CMAKE_C_COMPILER_ID MATCHES "^Clang$")
    IF (CMAKE_C_COMPILER_ID MATCHES "^XL$")
      SET(CMAKE_REQUIRED_FLAGS "${CMAKE_REQUIRED_FLAGS} -qhalt=w -qflag=w:w")
    ENDIF (CMAKE_C_COMPILER_ID MATCHES "^XL$")
    IF (MSVC)
      # NOTE: /WX option is the same as gcc's -Werror option.
      SET(CMAKE_REQUIRED_FLAGS "${CMAKE_REQUIRED_FLAGS} /WX")
    ENDIF (MSVC)
    #
    CHECK_C_SOURCE_COMPILES(
      "#include <stdlib.h>
       #include <iconv.h>
       int main() {
          ${TRY_ICONV_CONST} char *ccp;
          iconv_t cd = iconv_open(\"\", \"\");
          iconv(cd, &ccp, (size_t *)0, (char **)0, (size_t *)0);
          iconv_close(cd);
          return 0;
       }"
     HAVE_ICONV_${LIB}_${TRY_ICONV_CONST})
    IF(HAVE_ICONV_${LIB}_${TRY_ICONV_CONST})
      SET(HAVE_ICONV true)
      SET(ICONV_CONST ${TRY_ICONV_CONST})
    ENDIF(HAVE_ICONV_${LIB}_${TRY_ICONV_CONST})
    CMAKE_POP_CHECK_STATE()	# Restore the state of the variables
  ENDIF(NOT HAVE_ICONV)
ENDMACRO(CHECK_ICONV TRY_ICONV_CONST)

IF(ENABLE_ICONV)
  CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
  FIND_PATH(ICONV_INCLUDE_DIR iconv.h)
  IF(ICONV_INCLUDE_DIR)
    #SET(INCLUDES ${INCLUDES} "iconv.h")
    SET(HAVE_ICONV_H 1)
    INCLUDE_DIRECTORIES(${ICONV_INCLUDE_DIR})
    SET(CMAKE_REQUIRED_INCLUDES ${ICONV_INCLUDE_DIR})
    CHECK_ICONV("libc" "const")
    CHECK_ICONV("libc" "")

    # If iconv isn't in libc and we have a libiconv, try that.
    FIND_LIBRARY(LIBICONV_PATH NAMES iconv libiconv)
    IF(NOT HAVE_ICONV AND LIBICONV_PATH)
      LIST(APPEND CMAKE_REQUIRED_LIBRARIES ${LIBICONV_PATH})
      # Test if a macro is needed for the library.
      TRY_MACRO_FOR_LIBRARY(
        "${ICONV_INCLUDE_DIR}" "${LIBICONV_PATH}"
        COMPILES
        "#include <iconv.h>\nint main() {return iconv_close((iconv_t)0);}"
        "WITHOUT_LIBICONV_STATIC;LIBICONV_STATIC")
      IF(NOT WITHOUT_LIBICONV_STATIC AND LIBICONV_STATIC)
        ADD_DEFINITIONS(-DLIBICONV_STATIC)
      ENDIF(NOT WITHOUT_LIBICONV_STATIC AND LIBICONV_STATIC)
      #
      # Set up CMAKE_REQUIRED_* for CHECK_ICONV
      #
      SET(CMAKE_REQUIRED_INCLUDES ${ICONV_INCLUDE_DIR})
      SET(CMAKE_REQUIRED_LIBRARIES ${LIBICONV_PATH})
      IF(LIBICONV_STATIC)
        # LIBICONV_STATIC is necessary for the success of CHECK_ICONV
        # on Windows.
        SET(CMAKE_REQUIRED_DEFINITIONS "-DLIBICONV_STATIC")
      ELSE(LIBICONV_STATIC)
        SET(CMAKE_REQUIRED_DEFINITIONS)
      ENDIF(LIBICONV_STATIC)
      CHECK_ICONV("libiconv" "const")
      CHECK_ICONV("libiconv" "")
      IF (HAVE_ICONV)
        LIST(APPEND ADDITIONAL_LIBS ${LIBICONV_PATH})
      ENDIF(HAVE_ICONV)
    ENDIF(NOT HAVE_ICONV AND LIBICONV_PATH)
  ENDIF(ICONV_INCLUDE_DIR)
  #
  # Find locale_charset() for libiconv.
  #
  IF(LIBICONV_PATH)
    SET(CMAKE_REQUIRED_DEFINITIONS)
    SET(CMAKE_REQUIRED_INCLUDES ${ICONV_INCLUDE_DIR})
    SET(CMAKE_REQUIRED_LIBRARIES)
    CHECK_INCLUDE_FILES("localcharset.h" HAVE_LOCALCHARSET_H)
    FIND_LIBRARY(LIBCHARSET_PATH NAMES charset libcharset)
    IF(LIBCHARSET_PATH)
      SET(CMAKE_REQUIRED_LIBRARIES ${LIBCHARSET_PATH})
      IF(WIN32 AND NOT CYGWIN)
        # Test if a macro is needed for the library.
        TRY_MACRO_FOR_LIBRARY(
          "${ICONV_INCLUDE_DIR}" "${LIBCHARSET_PATH}"
          COMPILES
          "#include <localcharset.h>\nint main() {return locale_charset()?1:0;}"
          "WITHOUT_LIBCHARSET_STATIC;LIBCHARSET_STATIC")
        IF(NOT WITHOUT_LIBCHARSET_STATIC AND LIBCHARSET_STATIC)
          ADD_DEFINITIONS(-DLIBCHARSET_STATIC)
        ENDIF(NOT WITHOUT_LIBCHARSET_STATIC AND LIBCHARSET_STATIC)
        IF(WITHOUT_LIBCHARSET_STATIC OR LIBCHARSET_STATIC)
          SET(HAVE_LOCALE_CHARSET ON CACHE INTERNAL
              "Have function locale_charset")
        ENDIF(WITHOUT_LIBCHARSET_STATIC OR LIBCHARSET_STATIC)
      ELSE(WIN32 AND NOT CYGWIN)
        CHECK_FUNCTION_EXISTS_GLIBC(locale_charset HAVE_LOCALE_CHARSET)
      ENDIF(WIN32 AND NOT CYGWIN)
      IF(HAVE_LOCALE_CHARSET)
        LIST(APPEND ADDITIONAL_LIBS ${LIBCHARSET_PATH})
      ENDIF(HAVE_LOCALE_CHARSET)
    ENDIF(LIBCHARSET_PATH)
  ENDIF(LIBICONV_PATH)
  CMAKE_POP_CHECK_STATE()	# Restore the state of the variables
ELSE(ENABLE_ICONV)
  # Make sure ICONV variables are not in CACHE after ENABLE_ICONV disabled
  # (once enabled).
  UNSET(HAVE_LOCALE_CHARSET CACHE)
  UNSET(HAVE_ICONV CACHE)
  UNSET(HAVE_ICONV_libc_ CACHE)
  UNSET(HAVE_ICONV_libc_const CACHE)
  UNSET(HAVE_ICONV_libiconv_ CACHE)
  UNSET(HAVE_ICONV_libiconv_const CACHE)
  UNSET(ICONV_INCLUDE_DIR CACHE)
  UNSET(LIBICONV_PATH CACHE)
  UNSET(LIBICONV_DLL CACHE)
  UNSET(LIBICONV_STATIC CACHE)
  UNSET(LIBCHARSET_DLL CACHE)
  UNSET(LIBCHARSET_STATIC CACHE)
ENDIF(ENABLE_ICONV)

#
# Find Libxml2
#
IF(ENABLE_LIBXML2 AND HAVE_ICONV)
  FIND_PACKAGE(LibXml2 2.7.3)
ELSE()
  SET(LIBXML2_FOUND FALSE)
ENDIF()
IF(LIBXML2_FOUND)
  CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
  INCLUDE_DIRECTORIES(${LIBXML2_INCLUDE_DIR})
  LIST(APPEND ADDITIONAL_LIBS ${LIBXML2_LIBRARIES})
  SET(HAVE_LIBXML2 1)
  # libxml2's include files use iconv.h
  SET(CMAKE_REQUIRED_INCLUDES ${ICONV_INCLUDE_DIR} ${LIBXML2_INCLUDE_DIR})
  CHECK_INCLUDE_FILES("libxml/xmlreader.h" HAVE_LIBXML_XMLREADER_H)
  CHECK_INCLUDE_FILES("libxml/xmlwriter.h" HAVE_LIBXML_XMLWRITER_H)
  CHECK_INCLUDE_FILES("libxml/xmlversion.h" HAVE_LIBXML_XMLVERSION_H)
  # Test if a macro is needed for the library.
  TRY_MACRO_FOR_LIBRARY(
    "${ICONV_INCLUDE_DIR};${LIBXML2_INCLUDE_DIR}"
    "ws2_32.lib;${ZLIB_LIBRARIES};${LIBICONV_PATH};${LIBXML2_LIBRARIES}"
    COMPILES
    "#include <stddef.h>\n#include <libxml/xmlreader.h>\nint main() {return xmlTextReaderRead((xmlTextReaderPtr)(void *)0);}"
    "WITHOUT_LIBXML_STATIC;LIBXML_STATIC")
  IF(NOT WITHOUT_LIBXML_STATIC AND LIBXML_STATIC)
    ADD_DEFINITIONS(-DLIBXML_STATIC)
  ENDIF(NOT WITHOUT_LIBXML_STATIC AND LIBXML_STATIC)
  CMAKE_POP_CHECK_STATE()	# Restore the state of the variables
ELSE(LIBXML2_FOUND)
  #
  # Find XmlLite
  #
  IF(WIN32 AND ENABLE_WIN32_XMLLITE)
    # Check linkage as well; versions of mingw-w64 before v11.0.0
    # do not contain an import library for XmlLite.
    cmake_push_check_state()
    SET(CMAKE_REQUIRED_LIBRARIES "xmllite" "uuid")
    check_c_source_compiles("
    #include <initguid.h>
    #include <xmllite.h>
    int main() {
      return CreateXmlReader(&IID_IXmlReader, NULL, NULL);
    }
    " HAVE_XMLLITE_H)
    cmake_pop_check_state()
    IF(HAVE_XMLLITE_H)
      SET(HAVE_LIBXMLLITE 1)
      SET(XMLLITE_FOUND TRUE)
      LIST(APPEND ADDITIONAL_LIBS "xmllite" "uuid")
    ENDIF(HAVE_XMLLITE_H)
  ENDIF(WIN32 AND ENABLE_WIN32_XMLLITE)
  IF(NOT XMLLITE_FOUND)
    #
    # Find Expat
    #
    IF(ENABLE_EXPAT)
      FIND_PACKAGE(EXPAT)
    ELSE(ENABLE_EXPAT)
      SET(EXPAT_FOUND FALSE)
    ENDIF(ENABLE_EXPAT)
    IF(EXPAT_FOUND)
      CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
      INCLUDE_DIRECTORIES(${EXPAT_INCLUDE_DIRS})
      LIST(APPEND CMAKE_REQUIRED_INCLUDES ${EXPAT_INCLUDE_DIR})
      LIST(APPEND ADDITIONAL_LIBS ${EXPAT_LIBRARIES})
      SET(HAVE_LIBEXPAT 1)
      LA_CHECK_INCLUDE_FILE("expat.h" HAVE_EXPAT_H)
      CMAKE_POP_CHECK_STATE()	# Restore the state of the variables
    ENDIF(EXPAT_FOUND)
    #
    # Find bsdxml
    #
    IF(NOT EXPAT_FOUND)
      IF(ENABLE_BSDXML)
        FIND_PATH(BSDXML_INCLUDE_DIR NAMES bsdxml.h)
        FIND_LIBRARY(BSDXML_LIBRARY NAMES bsdxml)
        IF(BSDXML_INCLUDE_DIR AND BSDXML_LIBRARY)
          INCLUDE_DIRECTORIES(${BSDXML_INCLUDE_DIR})
          LIST(APPEND ADDITIONAL_LIBS ${BSDXML_LIBRARY})
          SET(HAVE_LIBBSDXML 1)
          LA_CHECK_INCLUDE_FILE("bsdxml.h" HAVE_BSDXML_H)
        ENDIF(BSDXML_INCLUDE_DIR AND BSDXML_LIBRARY)
      ENDIF(ENABLE_BSDXML)
    ENDIF(NOT EXPAT_FOUND)
  ENDIF(NOT XMLLITE_FOUND)
ENDIF(LIBXML2_FOUND)
MARK_AS_ADVANCED(CLEAR LIBXML2_INCLUDE_DIR)
MARK_AS_ADVANCED(CLEAR LIBXML2_LIBRARIES)

#
# POSIX Regular Expression support
#
IF(POSIX_REGEX_LIB MATCHES "^(AUTO|LIBC|LIBREGEX)$")
  #
  # If PCREPOSIX is not found or not requested, try using regex
  # from libc or libregex
  #
  FIND_PATH(REGEX_INCLUDE_DIR regex.h)
  IF(REGEX_INCLUDE_DIR)
    CHECK_FUNCTION_EXISTS_GLIBC(regcomp HAVE_REGCOMP_LIBC)
    #
    # If libc does not provide regex, find libregex.
    #
    IF(NOT HAVE_REGCOMP_LIBC)
      CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
      FIND_LIBRARY(REGEX_LIBRARY regex)
      IF(REGEX_LIBRARY)
        SET(CMAKE_REQUIRED_LIBRARIES ${REGEX_LIBRARY})
        CHECK_FUNCTION_EXISTS_GLIBC(regcomp HAVE_REGCOMP_LIBREGEX)
        IF(HAVE_REGCOMP_LIBREGEX)
          LIST(APPEND ADDITIONAL_LIBS ${REGEX_LIBRARY})
          #
          # If regex.h is not found, retry looking for regex.h at
          # REGEX_INCLUDE_DIR
          #
          IF(NOT HAVE_REGEX_H)
            UNSET(HAVE_REGEX_H CACHE)
            INCLUDE_DIRECTORIES(${REGEX_INCLUDE_DIR})
            SET(CMAKE_REQUIRED_INCLUDES ${REGEX_INCLUDE_DIR})
            LA_CHECK_INCLUDE_FILE("regex.h" HAVE_REGEX_H)
          ENDIF(NOT HAVE_REGEX_H)
          # Test if a macro is needed for the library.
          TRY_MACRO_FOR_LIBRARY(
            "${REGEX_INCLUDE_DIR}" "${REGEX_LIBRARY}"
            COMPILES
            "#include <stddef.h>\n#include <regex.h>\nint main() {regex_t r;return regcomp(&r, \"\", 0);}"
            "USE_REGEX_DLL;USE_REGEX_STATIC")
          IF(USE_REGEX_DLL)
            ADD_DEFINITIONS(-DUSE_REGEX_DLL)
          ELSEIF(USE_REGEX_STATIC)
            ADD_DEFINITIONS(-DUSE_REGEX_STATIC)
          ENDIF(USE_REGEX_DLL)
        ENDIF(HAVE_REGCOMP_LIBREGEX)
      ENDIF(REGEX_LIBRARY)
      CMAKE_POP_CHECK_STATE()	# Restore the state of the variables
    ENDIF(NOT HAVE_REGCOMP_LIBC)
  ENDIF(REGEX_INCLUDE_DIR)
  IF(HAVE_REGCOMP_LIBC OR HAVE_REGCOMP_LIBREGEX)
    SET(FOUND_POSIX_REGEX_LIB 1)
  ENDIF(HAVE_REGCOMP_LIBC OR HAVE_REGCOMP_LIBREGEX)
ENDIF(POSIX_REGEX_LIB MATCHES "^(AUTO|LIBC|LIBREGEX)$")

IF(NOT FOUND_POSIX_REGEX_LIB AND POSIX_REGEX_LIB MATCHES "^(AUTO|LIBPCREPOSIX)$")
  #
  # If requested, try finding library for PCREPOSIX
  #
  IF(ENABLE_LIBGCC)
    FIND_PACKAGE(LIBGCC)
  ELSE()
    MESSAGE(FATAL_ERROR "libgcc not found.")
    SET(LIBGCC_FOUND FALSE) # Override cached value
  ENDIF()
  IF(ENABLE_PCREPOSIX)
    FIND_PACKAGE(PCREPOSIX)
  ELSE()
    SET(PCREPOSIX_FOUND FALSE) # Override cached value
  ENDIF()
  IF(PCREPOSIX_FOUND)
    INCLUDE_DIRECTORIES(${PCRE_INCLUDE_DIR})
    LIST(APPEND ADDITIONAL_LIBS ${PCREPOSIX_LIBRARIES})
    # Test if a macro is needed for the library.
    TRY_MACRO_FOR_LIBRARY(
      "${PCRE_INCLUDE_DIR}" "${PCREPOSIX_LIBRARIES}"
      COMPILES
      "#include <pcreposix.h>\nint main() {regex_t r;return regcomp(&r, \"\", 0);}"
      "WITHOUT_PCRE_STATIC;PCRE_STATIC")
    IF(NOT WITHOUT_PCRE_STATIC AND PCRE_STATIC)
      ADD_DEFINITIONS(-DPCRE_STATIC)
	ELSEIF(NOT WITHOUT_PCRE_STATIC AND NOT PCRE_STATIC AND PCRE_FOUND)
	  # Determine if pcre static libraries are to be used.
      LIST(APPEND ADDITIONAL_LIBS ${PCRE_LIBRARIES})
      SET(TMP_LIBRARIES ${PCREPOSIX_LIBRARIES} ${PCRE_LIBRARIES})
      MESSAGE(STATUS "trying again with -lpcre included")
      TRY_MACRO_FOR_LIBRARY(
        "${PCRE_INCLUDE_DIR}" "${TMP_LIBRARIES}"
        COMPILES
        "#include <pcreposix.h>\nint main() {regex_t r;return regcomp(&r, \"\", 0);}"
        "WITHOUT_PCRE_STATIC;PCRE_STATIC")
      IF(NOT WITHOUT_PCRE_STATIC AND PCRE_STATIC)
        ADD_DEFINITIONS(-DPCRE_STATIC)
      ELSEIF(NOT WITHOUT_PCRE_STATIC AND NOT PCRE_STATIC AND MSVC AND LIBGCC_FOUND)
        # When doing a Visual Studio build using pcre static libraries
        # built using the mingw toolchain, -lgcc is needed to resolve
        # ___chkstk_ms.
        MESSAGE(STATUS "Visual Studio build detected, trying again with -lgcc included")
        LIST(APPEND ADDITIONAL_LIBS ${LIBGCC_LIBRARIES})
        SET(TMP_LIBRARIES ${PCREPOSIX_LIBRARIES} ${PCRE_LIBRARIES} ${LIBGCC_LIBRARIES})
          TRY_MACRO_FOR_LIBRARY(
            "${PCRE_INCLUDE_DIR}" "${TMP_LIBRARIES}"
            COMPILES
            "#include <pcreposix.h>\nint main() {regex_t r;return regcomp(&r, \"\", 0);}"
            "WITHOUT_PCRE_STATIC;PCRE_STATIC")
          IF(NOT WITHOUT_PCRE_STATIC AND PCRE_STATIC)
            ADD_DEFINITIONS(-DPCRE_STATIC)
          ENDIF(NOT WITHOUT_PCRE_STATIC AND PCRE_STATIC)
      ENDIF(NOT WITHOUT_PCRE_STATIC AND PCRE_STATIC)
    ENDIF(NOT WITHOUT_PCRE_STATIC AND PCRE_STATIC)
  ENDIF(PCREPOSIX_FOUND)
  MARK_AS_ADVANCED(CLEAR PCRE_INCLUDE_DIR)
  MARK_AS_ADVANCED(CLEAR PCREPOSIX_LIBRARIES)
  MARK_AS_ADVANCED(CLEAR PCRE_LIBRARIES)
  MARK_AS_ADVANCED(CLEAR LIBGCC_LIBRARIES)
ENDIF(NOT FOUND_POSIX_REGEX_LIB AND POSIX_REGEX_LIB MATCHES "^(AUTO|LIBPCREPOSIX)$")

IF(NOT FOUND_POSIX_REGEX_LIB AND POSIX_REGEX_LIB MATCHES "^(AUTO|LIBPCRE2POSIX)$")
  #
  # If requested, try finding library for PCRE2POSIX
  #
  IF(ENABLE_LIBGCC)
    FIND_PACKAGE(LIBGCC)
  ELSE()
    MESSAGE(FATAL_ERROR "libgcc not found.")
    SET(LIBGCC_FOUND FALSE) # Override cached value
  ENDIF()
  IF(ENABLE_PCRE2POSIX)
    FIND_PACKAGE(PCRE2POSIX)
  ELSE()
    SET(PCRE2POSIX_FOUND FALSE) # Override cached value
  ENDIF()
  IF(PCRE2POSIX_FOUND)
    INCLUDE_DIRECTORIES(${PCRE2_INCLUDE_DIR})
    LIST(APPEND ADDITIONAL_LIBS ${PCRE2POSIX_LIBRARIES})
    # Test if a macro is needed for the library.
    TRY_MACRO_FOR_LIBRARY(
      "${PCRE2_INCLUDE_DIR}" "${PCRE2POSIX_LIBRARIES}"
      COMPILES
      "#include <pcre2posix.h>\nint main() {regex_t r;return pcre2_regcomp(&r, \"\", 0);}"
      "WITHOUT_PCRE2_STATIC;PCRE2_STATIC")
    IF(NOT WITHOUT_PCRE2_STATIC AND PCRE2_STATIC)
      ADD_DEFINITIONS(-DPCRE2_STATIC)
	ELSEIF(NOT WITHOUT_PCRE2_STATIC AND NOT PCRE2_STATIC AND PCRE2_FOUND)
	  # Determine if pcre2 static libraries are to be used.
      LIST(APPEND ADDITIONAL_LIBS ${PCRE2_LIBRARIES})
      SET(TMP_LIBRARIES ${PCRE2POSIX_LIBRARIES} ${PCRE2_LIBRARIES})
      MESSAGE(STATUS "trying again with -lpcre2-8 included")
      TRY_MACRO_FOR_LIBRARY(
        "${PCRE2_INCLUDE_DIR}" "${TMP_LIBRARIES}"
        COMPILES
        "#include <pcre2posix.h>\nint main() {regex_t r;return pcre2_regcomp(&r, \"\", 0);}"
        "WITHOUT_PCRE2_STATIC;PCRE2_STATIC")
      IF(NOT WITHOUT_PCRE2_STATIC AND PCRE2_STATIC)
        ADD_DEFINITIONS(-DPCRE2_STATIC)
      ELSEIF(NOT WITHOUT_PCRE2_STATIC AND NOT PCRE2_STATIC AND MSVC AND LIBGCC_FOUND)
        # When doing a Visual Studio build using pcre2 static libraries
        # built using the mingw toolchain, -lgcc is needed to resolve
        # ___chkstk_ms.
        MESSAGE(STATUS "Visual Studio build detected, trying again with -lgcc included")
        LIST(APPEND ADDITIONAL_LIBS ${LIBGCC_LIBRARIES})
        SET(TMP_LIBRARIES ${PCRE2POSIX_LIBRARIES} ${PCRE2_LIBRARIES} ${LIBGCC_LIBRARIES})
          TRY_MACRO_FOR_LIBRARY(
            "${PCRE2_INCLUDE_DIR}" "${TMP_LIBRARIES}"
            COMPILES
            "#include <pcre2posix.h>\nint main() {regex_t r;return pcre2_regcomp(&r, \"\", 0);}"
            "WITHOUT_PCRE2_STATIC;PCRE2_STATIC")
          IF(NOT WITHOUT_PCRE2_STATIC AND PCRE2_STATIC)
            ADD_DEFINITIONS(-DPCRE2_STATIC)
          ENDIF(NOT WITHOUT_PCRE2_STATIC AND PCRE2_STATIC)
      ENDIF(NOT WITHOUT_PCRE2_STATIC AND PCRE2_STATIC)
    ENDIF(NOT WITHOUT_PCRE2_STATIC AND PCRE2_STATIC)
  ENDIF(PCRE2POSIX_FOUND)
  MARK_AS_ADVANCED(CLEAR PCRE2_INCLUDE_DIR)
  MARK_AS_ADVANCED(CLEAR PCRE2POSIX_LIBRARIES)
  MARK_AS_ADVANCED(CLEAR PCRE2_LIBRARIES)
  MARK_AS_ADVANCED(CLEAR LIBGCC_LIBRARIES)
ENDIF(NOT FOUND_POSIX_REGEX_LIB AND POSIX_REGEX_LIB MATCHES "^(AUTO|LIBPCRE2POSIX)$")

#
# Check functions
#
CMAKE_PUSH_CHECK_STATE()	# Save the state of the variables
IF (CMAKE_C_COMPILER_ID MATCHES "^GNU$" OR
    CMAKE_C_COMPILER_ID MATCHES "^Clang$")
  #
  # During checking functions, we should use -fno-builtin to avoid the
  # failure of function detection which failure is an error "conflicting
  # types for built-in function" caused by using -Werror option.
  #
  SET(CMAKE_REQUIRED_FLAGS "${CMAKE_REQUIRED_FLAGS} -fno-builtin")
ENDIF (CMAKE_C_COMPILER_ID MATCHES "^GNU$" OR
       CMAKE_C_COMPILER_ID MATCHES "^Clang$")
IF (MSVC)
  #
  # The Windows CRT marks a number of standard functions (e.g. wcscpy) as
  # deprecated. All source files in this project are compiled with those
  # deprecations suppressed, so suppress these warnings for the following
  # symbol checks as well. Otherwise, the deprecation warnings get turned into
  # errors by ENABLE_WERROR's /WX flag and the check fails even when the
  # function exists.
  #
  LIST(APPEND CMAKE_REQUIRED_DEFINITIONS -D_CRT_SECURE_NO_DEPRECATE -D_CRT_NONSTDC_NO_WARNINGS)
ENDIF (MSVC)
CHECK_SYMBOL_EXISTS(_CrtSetReportMode "crtdbg.h" HAVE__CrtSetReportMode)
CHECK_FUNCTION_EXISTS_GLIBC(arc4random_buf HAVE_ARC4RANDOM_BUF)
CHECK_FUNCTION_EXISTS_GLIBC(chflags HAVE_CHFLAGS)
CHECK_FUNCTION_EXISTS_GLIBC(chown HAVE_CHOWN)
CHECK_FUNCTION_EXISTS_GLIBC(chroot HAVE_CHROOT)
CHECK_FUNCTION_EXISTS_GLIBC(closefrom HAVE_CLOSEFROM)
CHECK_FUNCTION_EXISTS_GLIBC(close_range HAVE_CLOSE_RANGE)
CHECK_FUNCTION_EXISTS_GLIBC(ctime_r HAVE_CTIME_R)
CHECK_FUNCTION_EXISTS_GLIBC(explicit_bzero HAVE_EXPLICIT_BZERO)
CHECK_FUNCTION_EXISTS_GLIBC(fchdir HAVE_FCHDIR)
CHECK_FUNCTION_EXISTS_GLIBC(fchflags HAVE_FCHFLAGS)
CHECK_FUNCTION_EXISTS_GLIBC(fchmod HAVE_FCHMOD)
CHECK_FUNCTION_EXISTS_GLIBC(fchown HAVE_FCHOWN)
CHECK_FUNCTION_EXISTS_GLIBC(fcntl HAVE_FCNTL)
CHECK_FUNCTION_EXISTS_GLIBC(fdopendir HAVE_FDOPENDIR)
CHECK_FUNCTION_EXISTS_GLIBC(fnmatch HAVE_FNMATCH)
CHECK_FUNCTION_EXISTS_GLIBC(fork HAVE_FORK)
CHECK_FUNCTION_EXISTS_GLIBC(fstat HAVE_FSTAT)
CHECK_FUNCTION_EXISTS_GLIBC(fstatat HAVE_FSTATAT)
CHECK_FUNCTION_EXISTS_GLIBC(fstatfs HAVE_FSTATFS)
CHECK_FUNCTION_EXISTS_GLIBC(fstatvfs HAVE_FSTATVFS)
CHECK_FUNCTION_EXISTS_GLIBC(ftruncate HAVE_FTRUNCATE)
CHECK_FUNCTION_EXISTS_GLIBC(futimens HAVE_FUTIMENS)
CHECK_FUNCTION_EXISTS_GLIBC(futimes HAVE_FUTIMES)
CHECK_FUNCTION_EXISTS_GLIBC(futimesat HAVE_FUTIMESAT)
CHECK_FUNCTION_EXISTS_GLIBC(getegid HAVE_GETEGID)
CHECK_FUNCTION_EXISTS_GLIBC(geteuid HAVE_GETEUID)
CHECK_FUNCTION_EXISTS_GLIBC(getgrgid_r HAVE_GETGRGID_R)
CHECK_FUNCTION_EXISTS_GLIBC(getgrnam_r HAVE_GETGRNAM_R)
CHECK_FUNCTION_EXISTS_GLIBC(getline HAVE_GETLINE)
CHECK_FUNCTION_EXISTS_GLIBC(getpid HAVE_GETPID)
CHECK_FUNCTION_EXISTS_GLIBC(getpwnam_r HAVE_GETPWNAM_R)
CHECK_FUNCTION_EXISTS_GLIBC(getpwuid_r HAVE_GETPWUID_R)
CHECK_FUNCTION_EXISTS_GLIBC(getresgid HAVE_GETRESGID)
CHECK_FUNCTION_EXISTS_GLIBC(getresuid HAVE_GETRESUID)
CHECK_FUNCTION_EXISTS_GLIBC(gettimeofday HAVE_GETTIMEOFDAY)
CHECK_FUNCTION_EXISTS_GLIBC(getvfsbyname HAVE_GETVFSBYNAME)
CHECK_FUNCTION_EXISTS_GLIBC(gmtime_r HAVE_GMTIME_R)
CHECK_FUNCTION_EXISTS_GLIBC(issetugid HAVE_ISSETUGID)
CHECK_FUNCTION_EXISTS_GLIBC(lchflags HAVE_LCHFLAGS)
CHECK_FUNCTION_EXISTS_GLIBC(lchmod HAVE_LCHMOD)
CHECK_FUNCTION_EXISTS_GLIBC(lchown HAVE_LCHOWN)
CHECK_FUNCTION_EXISTS_GLIBC(link HAVE_LINK)
CHECK_FUNCTION_EXISTS_GLIBC(linkat HAVE_LINKAT)
CHECK_FUNCTION_EXISTS_GLIBC(localtime_r HAVE_LOCALTIME_R)
CHECK_FUNCTION_EXISTS_GLIBC(lstat HAVE_LSTAT)
CHECK_FUNCTION_EXISTS_GLIBC(lutimes HAVE_LUTIMES)
CHECK_FUNCTION_EXISTS_GLIBC(mbrtowc HAVE_MBRTOWC)
CHECK_FUNCTION_EXISTS_GLIBC(memmove HAVE_MEMMOVE)
CHECK_FUNCTION_EXISTS_GLIBC(memset_explicit HAVE_MEMSET_EXPLICIT)
CHECK_FUNCTION_EXISTS_GLIBC(mkdir HAVE_MKDIR)
CHECK_FUNCTION_EXISTS_GLIBC(mkfifo HAVE_MKFIFO)
CHECK_FUNCTION_EXISTS_GLIBC(mknod HAVE_MKNOD)
CHECK_FUNCTION_EXISTS_GLIBC(mkstemp HAVE_MKSTEMP)
CHECK_FUNCTION_EXISTS_GLIBC(nl_langinfo HAVE_NL_LANGINFO)
CHECK_FUNCTION_EXISTS_GLIBC(openat HAVE_OPENAT)
CHECK_FUNCTION_EXISTS_GLIBC(pipe HAVE_PIPE)
CHECK_FUNCTION_EXISTS_GLIBC(poll HAVE_POLL)
CHECK_FUNCTION_EXISTS_GLIBC(posix_spawn HAVE_POSIX_SPAWN)
CHECK_FUNCTION_EXISTS_GLIBC(posix_spawnp HAVE_POSIX_SPAWNP)
CHECK_FUNCTION_EXISTS_GLIBC(readlink HAVE_READLINK)
CHECK_FUNCTION_EXISTS_GLIBC(readpassphrase HAVE_READPASSPHRASE)
CHECK_FUNCTION_EXISTS_GLIBC(select HAVE_SELECT)
CHECK_FUNCTION_EXISTS_GLIBC(setenv HAVE_SETENV)
CHECK_FUNCTION_EXISTS_GLIBC(setlocale HAVE_SETLOCALE)
CHECK_FUNCTION_EXISTS_GLIBC(sigaction HAVE_SIGACTION)
CHECK_FUNCTION_EXISTS_GLIBC(statfs HAVE_STATFS)
CHECK_FUNCTION_EXISTS_GLIBC(statvfs HAVE_STATVFS)
CHECK_FUNCTION_EXISTS_GLIBC(strchr HAVE_STRCHR)
CHECK_FUNCTION_EXISTS_GLIBC(strdup HAVE_STRDUP)
CHECK_FUNCTION_EXISTS_GLIBC(strerror HAVE_STRERROR)
CHECK_FUNCTION_EXISTS_GLIBC(strncpy_s HAVE_STRNCPY_S)
CHECK_FUNCTION_EXISTS_GLIBC(strnlen HAVE_STRNLEN)
CHECK_FUNCTION_EXISTS_GLIBC(strrchr HAVE_STRRCHR)
CHECK_FUNCTION_EXISTS_GLIBC(symlink HAVE_SYMLINK)
CHECK_FUNCTION_EXISTS_GLIBC(sysconf HAVE_SYSCONF)
CHECK_FUNCTION_EXISTS_GLIBC(tcgetattr HAVE_TCGETATTR)
CHECK_FUNCTION_EXISTS_GLIBC(tcsetattr HAVE_TCSETATTR)
CHECK_FUNCTION_EXISTS_GLIBC(timegm HAVE_TIMEGM)
CHECK_FUNCTION_EXISTS_GLIBC(tzset HAVE_TZSET)
CHECK_FUNCTION_EXISTS_GLIBC(unlinkat HAVE_UNLINKAT)
CHECK_FUNCTION_EXISTS_GLIBC(unsetenv HAVE_UNSETENV)
CHECK_FUNCTION_EXISTS_GLIBC(utime HAVE_UTIME)
CHECK_FUNCTION_EXISTS_GLIBC(utimes HAVE_UTIMES)
CHECK_FUNCTION_EXISTS_GLIBC(utimensat HAVE_UTIMENSAT)
CHECK_FUNCTION_EXISTS_GLIBC(vfork HAVE_VFORK)
CHECK_FUNCTION_EXISTS_GLIBC(wcrtomb HAVE_WCRTOMB)
check_symbol_exists(wcscmp wchar.h HAVE_WCSCMP)
check_symbol_exists(wcscpy wchar.h HAVE_WCSCPY)
check_symbol_exists(wcslen wchar.h HAVE_WCSLEN)
CHECK_FUNCTION_EXISTS_GLIBC(wctomb HAVE_WCTOMB)
CHECK_FUNCTION_EXISTS_GLIBC(_fseeki64 HAVE__FSEEKI64)
CHECK_FUNCTION_EXISTS_GLIBC(_get_timezone HAVE__GET_TIMEZONE)
CHECK_SYMBOL_EXISTS(ctime_s "time.h" HAVE_CTIME_S)
CHECK_SYMBOL_EXISTS(gmtime_s "time.h" HAVE_GMTIME_S)
CHECK_SYMBOL_EXISTS(localtime_s "time.h" HAVE_LOCALTIME_S)
CHECK_SYMBOL_EXISTS(_mkgmtime "time.h" HAVE__MKGMTIME)

SET(CMAKE_REQUIRED_LIBRARIES "")
CHECK_FUNCTION_EXISTS(cygwin_conv_path HAVE_CYGWIN_CONV_PATH)
CHECK_FUNCTION_EXISTS(fseeko HAVE_FSEEKO)
CHECK_FUNCTION_EXISTS(strerror_r HAVE_STRERROR_R)
CHECK_FUNCTION_EXISTS(strftime HAVE_STRFTIME)
CHECK_FUNCTION_EXISTS(vprintf HAVE_VPRINTF)
CHECK_FUNCTION_EXISTS(waitpid HAVE_WAITPID)
CHECK_FUNCTION_EXISTS(wmemcmp HAVE_WMEMCMP)
CHECK_FUNCTION_EXISTS(wmemcpy HAVE_WMEMCPY)
CHECK_FUNCTION_EXISTS(wmemmove HAVE_WMEMMOVE)

CMAKE_POP_CHECK_STATE()	# Restore the state of the variables

CHECK_C_SOURCE_COMPILES(
  "#include <sys/types.h>\n#include <sys/mount.h>\nint main(void) { struct vfsconf v; return sizeof(v);}"
  HAVE_STRUCT_VFSCONF)

CHECK_C_SOURCE_COMPILES(
  "#include <sys/types.h>\n#include <sys/mount.h>\nint main(void) { struct xvfsconf v; return sizeof(v);}"
  HAVE_STRUCT_XVFSCONF)

CHECK_C_SOURCE_COMPILES(
  "#include <sys/types.h>\n#include <sys/mount.h>\nint main(void) { struct statfs s; return sizeof(s);}"
  HAVE_STRUCT_STATFS)

# dirfd can be either a function or a macro.
CHECK_C_SOURCE_COMPILES(
  "#include <dirent.h>\nint main() {DIR *d = opendir(\".\"); return dirfd(d);}"
  HAVE_DIRFD)

# Only detect readlinkat() if we also have AT_FDCWD in unistd.h.
# NOTE: linux requires fcntl.h for AT_FDCWD.
CHECK_C_SOURCE_COMPILES(
  "#include <fcntl.h>\n#include <unistd.h>\nint main() {char buf[10]; return readlinkat(AT_FDCWD, \"\", buf, 0);}"
  HAVE_READLINKAT)

# To verify major(), we need to both include the header
# of interest and verify that the result can be linked.
# CHECK_FUNCTION_EXISTS doesn't accept a header argument,
# CHECK_SYMBOL_EXISTS doesn't test linkage.
CHECK_C_SOURCE_COMPILES(
  "#include <sys/mkdev.h>\nint main() { return major(256); }"
  MAJOR_IN_MKDEV)
CHECK_C_SOURCE_COMPILES(
  "#include <sys/sysmacros.h>\nint main() { return major(256); }"
  MAJOR_IN_SYSMACROS)

IF(HAVE_STRERROR_R)
  SET(HAVE_DECL_STRERROR_R 1)
ENDIF(HAVE_STRERROR_R)

#
# Check defines
#
SET(headers "limits.h")
IF(HAVE_STDINT_H)
  LIST(APPEND headers "stdint.h")
ENDIF(HAVE_STDINT_H)
IF(HAVE_INTTYPES_H)
  LIST(APPEND headers "inttypes.h")
ENDIF(HAVE_INTTYPES_H)
CHECK_SYMBOL_EXISTS(EFTYPE           "errno.h"    HAVE_EFTYPE)
CHECK_SYMBOL_EXISTS(EILSEQ           "errno.h"    HAVE_EILSEQ)
CHECK_SYMBOL_EXISTS(D_MD_ORDER       "langinfo.h" HAVE_D_MD_ORDER)
CHECK_SYMBOL_EXISTS(INT32_MAX        "${headers}" HAVE_DECL_INT32_MAX)
CHECK_SYMBOL_EXISTS(INT32_MIN        "${headers}" HAVE_DECL_INT32_MIN)
CHECK_SYMBOL_EXISTS(INT64_MAX        "${headers}" HAVE_DECL_INT64_MAX)
CHECK_SYMBOL_EXISTS(INT64_MIN        "${headers}" HAVE_DECL_INT64_MIN)
CHECK_SYMBOL_EXISTS(INTMAX_MAX       "${headers}" HAVE_DECL_INTMAX_MAX)
CHECK_SYMBOL_EXISTS(INTMAX_MIN       "${headers}" HAVE_DECL_INTMAX_MIN)
CHECK_SYMBOL_EXISTS(UINT32_MAX       "${headers}" HAVE_DECL_UINT32_MAX)
CHECK_SYMBOL_EXISTS(UINT64_MAX       "${headers}" HAVE_DECL_UINT64_MAX)
CHECK_SYMBOL_EXISTS(UINTMAX_MAX      "${headers}" HAVE_DECL_UINTMAX_MAX)
CHECK_SYMBOL_EXISTS(SIZE_MAX         "${headers}" HAVE_DECL_SIZE_MAX)
CHECK_SYMBOL_EXISTS(SSIZE_MAX        "limits.h"   HAVE_DECL_SSIZE_MAX)

#
# Check struct members
#
# Check for tm_gmtoff in struct tm
CHECK_STRUCT_HAS_MEMBER("struct tm" tm_gmtoff
    "time.h" HAVE_STRUCT_TM_TM_GMTOFF)
CHECK_STRUCT_HAS_MEMBER("struct tm" __tm_gmtoff
    "time.h" HAVE_STRUCT_TM___TM_GMTOFF)

IF(HAVE_STRUCT_STATFS)
# Check for f_namemax in struct statfs
CHECK_STRUCT_HAS_MEMBER("struct statfs" f_namemax
    "sys/param.h;sys/mount.h" HAVE_STRUCT_STATFS_F_NAMEMAX)
# Check for f_iosize in struct statfs
CHECK_STRUCT_HAS_MEMBER("struct statfs" f_iosize
    "sys/param.h;sys/mount.h" HAVE_STRUCT_STATFS_F_IOSIZE)
ENDIF(HAVE_STRUCT_STATFS)

# Check for birthtime in struct stat
CHECK_STRUCT_HAS_MEMBER("struct stat" st_birthtime
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_BIRTHTIME)

# Check for high-resolution timestamps in struct stat
CHECK_STRUCT_HAS_MEMBER("struct stat" st_birthtimespec.tv_nsec
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_BIRTHTIMESPEC_TV_NSEC)
CHECK_STRUCT_HAS_MEMBER("struct stat" st_mtimespec.tv_nsec
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_MTIMESPEC_TV_NSEC)
CHECK_STRUCT_HAS_MEMBER("struct stat" st_mtim.tv_nsec
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_MTIM_TV_NSEC)
CHECK_STRUCT_HAS_MEMBER("struct stat" st_mtime_n
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_MTIME_N)
CHECK_STRUCT_HAS_MEMBER("struct stat" st_umtime
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_UMTIME)
CHECK_STRUCT_HAS_MEMBER("struct stat" st_mtime_usec
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_MTIME_USEC)
# Check for block size support in struct stat
CHECK_STRUCT_HAS_MEMBER("struct stat" st_blksize
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_BLKSIZE)
# Check for st_flags in struct stat (BSD fflags)
CHECK_STRUCT_HAS_MEMBER("struct stat" st_flags
    "sys/types.h;sys/stat.h" HAVE_STRUCT_STAT_ST_FLAGS)

IF(HAVE_SYS_STATVFS_H)
  CHECK_STRUCT_HAS_MEMBER("struct statvfs" f_iosize
    "sys/types.h;sys/statvfs.h" HAVE_STRUCT_STATVFS_F_IOSIZE)
ENDIF()

#
#
CHECK_STRUCT_HAS_MEMBER("struct tm" tm_sec
    "sys/types.h;sys/time.h;time.h" HAVE_SYS_TIME_H)

#
# Check for integer types
#
#
CHECK_TYPE_SIZE("short" SIZEOF_SHORT)
CHECK_TYPE_SIZE("int" SIZEOF_INT)
CHECK_TYPE_SIZE("long" SIZEOF_LONG)
CHECK_TYPE_SIZE("long long"     SIZEOF_LONG_LONG)

CHECK_TYPE_SIZE("unsigned short" SIZEOF_UNSIGNED_SHORT)
CHECK_TYPE_SIZE("unsigned" SIZEOF_UNSIGNED)
CHECK_TYPE_SIZE("unsigned long" SIZEOF_UNSIGNED_LONG)
CHECK_TYPE_SIZE("unsigned long long" SIZEOF_UNSIGNED_LONG_LONG)

CHECK_TYPE_SIZE("__int64" __INT64)
CHECK_TYPE_SIZE("unsigned __int64" UNSIGNED___INT64)

CHECK_TYPE_SIZE(int16_t INT16_T)
CHECK_TYPE_SIZE(int32_t INT32_T)
CHECK_TYPE_SIZE(int64_t INT64_T)
CHECK_TYPE_SIZE(intmax_t INTMAX_T)
CHECK_TYPE_SIZE(uint8_t UINT8_T)
CHECK_TYPE_SIZE(uint16_t UINT16_T)
CHECK_TYPE_SIZE(uint32_t UINT32_T)
CHECK_TYPE_SIZE(uint64_t UINT64_T)
CHECK_TYPE_SIZE(uintmax_t UINTMAX_T)

CHECK_TYPE_SIZE(dev_t       DEV_T)
IF(NOT HAVE_DEV_T)
  IF(MSVC)
    SET(dev_t "unsigned int")
  ENDIF(MSVC)
ENDIF(NOT HAVE_DEV_T)
#
CHECK_TYPE_SIZE(gid_t       GID_T)
IF(NOT HAVE_GID_T)
  IF(WIN32)
    SET(gid_t "short")
  ELSE(WIN32)
    SET(gid_t "unsigned int")
  ENDIF(WIN32)
ENDIF(NOT HAVE_GID_T)
#
CHECK_TYPE_SIZE(id_t        ID_T)
IF(NOT HAVE_ID_T)
  IF(WIN32)
    SET(id_t "short")
  ELSE(WIN32)
    SET(id_t "unsigned int")
  ENDIF(WIN32)
ENDIF(NOT HAVE_ID_T)
#
CHECK_TYPE_SIZE(mode_t      MODE_T)
IF(NOT HAVE_MODE_T)
  IF(WIN32)
    SET(mode_t "unsigned short")
  ELSE(WIN32)
    SET(mode_t "int")
  ENDIF(WIN32)
ENDIF(NOT HAVE_MODE_T)
#
CHECK_TYPE_SIZE(off_t       OFF_T)
IF(NOT HAVE_OFF_T)
  SET(off_t "__int64")
ENDIF(NOT HAVE_OFF_T)
#
CHECK_TYPE_SIZE(size_t      SIZE_T)
IF(NOT HAVE_SIZE_T)
  IF("${CMAKE_SIZEOF_VOID_P}" EQUAL 8)
    SET(size_t "uint64_t")
  ELSE("${CMAKE_SIZEOF_VOID_P}" EQUAL 8)
    SET(size_t   "uint32_t")
  ENDIF("${CMAKE_SIZEOF_VOID_P}" EQUAL 8)
ENDIF(NOT HAVE_SIZE_T)
#
CHECK_TYPE_SIZE(ssize_t     SSIZE_T)
IF(NOT HAVE_SSIZE_T)
  IF("${CMAKE_SIZEOF_VOID_P}" EQUAL 8)
    SET(ssize_t "int64_t")
  ELSE("${CMAKE_SIZEOF_VOID_P}" EQUAL 8)
    SET(ssize_t "long")
  ENDIF("${CMAKE_SIZEOF_VOID_P}" EQUAL 8)
ENDIF(NOT HAVE_SSIZE_T)
#
CHECK_TYPE_SIZE(uid_t       UID_T)
IF(NOT HAVE_UID_T)
  IF(WIN32)
    SET(uid_t "short")
  ELSE(WIN32)
    SET(uid_t "unsigned int")
  ENDIF(WIN32)
ENDIF(NOT HAVE_UID_T)
#
CHECK_TYPE_SIZE(pid_t       PID_T)
IF(NOT HAVE_PID_T)
  IF(WIN32)
    SET(pid_t "int")
  ELSE(WIN32)
    MESSAGE(FATAL_ERROR "pid_t doesn't exist on this platform?")
  ENDIF(WIN32)
ENDIF(NOT HAVE_PID_T)
#
CHECK_TYPE_SIZE(intptr_t   INTPTR_T)
IF(NOT HAVE_INTPTR_T)
  IF("${CMAKE_SIZEOF_VOID_P}" EQUAL 8)
    SET(intptr_t "int64_t")
  ELSE()
    SET(intptr_t "int32_t")
  ENDIF()
ENDIF(NOT HAVE_INTPTR_T)
#
CHECK_TYPE_SIZE(uintptr_t   UINTPTR_T)
IF(NOT HAVE_UINTPTR_T)
  IF("${CMAKE_SIZEOF_VOID_P}" EQUAL 8)
    SET(uintptr_t "uint64_t")
  ELSE()
    SET(uintptr_t "uint32_t")
  ENDIF()
ENDIF(NOT HAVE_UINTPTR_T)
#
CHECK_TYPE_SIZE(wchar_t     SIZEOF_WCHAR_T)
IF(HAVE_SIZEOF_WCHAR_T)
  SET(HAVE_WCHAR_T 1)
ENDIF(HAVE_SIZEOF_WCHAR_T)
#
# Check if _FILE_OFFSET_BITS macro needed for large files
#
CHECK_FILE_OFFSET_BITS()

#
# Check for Extended Attribute libraries, headers, and functions
#
IF(ENABLE_XATTR)
  CHECK_LIBRARY_EXISTS(attr "setxattr" "" HAVE_LIBATTR)
  IF(HAVE_LIBATTR)
    SET(CMAKE_REQUIRED_LIBRARIES "attr")
	  pkg_check_modules(LIBATTR libattr)
	  IF(LIBATTR_VERSION)
	    SET(LIBATTR_PKGCONFIG_VERSION ${LIBATTR_VERSION})
	  ENDIF(LIBATTR_VERSION)
  ELSE(HAVE_LIBATTR)
    CHECK_LIBRARY_EXISTS(gnu "setxattr" "" HAVE_LIBATTR_GNU)
    IF(HAVE_LIBATTR_GNU)
      SET(CMAKE_REQUIRED_LIBRARIES "gnu")
    ENDIF()
    UNSET(LIBATTR_PKGCONFIG_VERSION CACHE)
  ENDIF(HAVE_LIBATTR)
  CHECK_SYMBOL_EXISTS(EXTATTR_NAMESPACE_USER "sys/types.h;sys/extattr.h" HAVE_DECL_EXTATTR_NAMESPACE_USER)
  CHECK_SYMBOL_EXISTS(XATTR_NOFOLLOW "sys/xattr.h" HAVE_DECL_XATTR_NOFOLLOW)
  IF(HAVE_SYS_XATTR_H AND HAVE_DECL_XATTR_NOFOLLOW)
    CHECK_FUNCTION_EXISTS(fgetxattr HAVE_FGETXATTR)
    CHECK_FUNCTION_EXISTS(flistxattr HAVE_FLISTXATTR)
    CHECK_FUNCTION_EXISTS(fsetxattr HAVE_FSETXATTR)
    CHECK_FUNCTION_EXISTS(getxattr HAVE_GETXATTR)
    CHECK_FUNCTION_EXISTS(listxattr HAVE_LISTXATTR)
    CHECK_FUNCTION_EXISTS(setxattr HAVE_SETXATTR)
    IF(HAVE_FGETXATTR AND
       HAVE_FLISTXATTR AND
       HAVE_FSETXATTR AND
       HAVE_GETXATTR AND
       HAVE_LISTXATTR AND
       HAVE_SETXATTR)
      SET(ARCHIVE_XATTR_DARWIN TRUE)
    ENDIF()
  ELSEIF(HAVE_SYS_EXTATTR_H AND HAVE_DECL_EXTATTR_NAMESPACE_USER)
    # FreeBSD xattr support
    CHECK_FUNCTION_EXISTS(extattr_get_fd HAVE_EXTATTR_GET_FD)
    CHECK_FUNCTION_EXISTS(extattr_get_file HAVE_EXTATTR_GET_FILE)
    CHECK_FUNCTION_EXISTS(extattr_get_link HAVE_EXTATTR_GET_LINK)
    CHECK_FUNCTION_EXISTS(extattr_list_fd HAVE_EXTATTR_LIST_FD)
    CHECK_FUNCTION_EXISTS(extattr_list_file HAVE_EXTATTR_LIST_FILE)
    CHECK_FUNCTION_EXISTS(extattr_list_link HAVE_EXTATTR_LIST_LINK)
    CHECK_FUNCTION_EXISTS(extattr_set_fd HAVE_EXTATTR_SET_FD)
    CHECK_FUNCTION_EXISTS(extattr_set_link HAVE_EXTATTR_SET_LINK)
    IF(HAVE_EXTATTR_GET_FD AND
       HAVE_EXTATTR_GET_FILE AND
       HAVE_EXTATTR_GET_LINK AND
       HAVE_EXTATTR_LIST_FD AND
       HAVE_EXTATTR_LIST_FILE AND
       HAVE_EXTATTR_LIST_LINK AND
       HAVE_EXTATTR_SET_FD AND
       HAVE_EXTATTR_SET_LINK)
      SET(ARCHIVE_XATTR_FREEBSD TRUE)
    ENDIF()
  ELSEIF(HAVE_SYS_XATTR_H OR HAVE_ATTR_XATTR_H)
    # Linux xattr support
    CHECK_FUNCTION_EXISTS_GLIBC(fgetxattr HAVE_FGETXATTR)
    CHECK_FUNCTION_EXISTS_GLIBC(flistxattr HAVE_FLISTXATTR)
    CHECK_FUNCTION_EXISTS_GLIBC(fsetxattr HAVE_FSETXATTR)
    CHECK_FUNCTION_EXISTS_GLIBC(getxattr HAVE_GETXATTR)
    CHECK_FUNCTION_EXISTS_GLIBC(lgetxattr HAVE_LGETXATTR)
    CHECK_FUNCTION_EXISTS_GLIBC(listxattr HAVE_LISTXATTR)
    CHECK_FUNCTION_EXISTS_GLIBC(llistxattr HAVE_LLISTXATTR)
    CHECK_FUNCTION_EXISTS_GLIBC(lsetxattr HAVE_LSETXATTR)
    IF(HAVE_FGETXATTR AND
       HAVE_FLISTXATTR AND
       HAVE_FSETXATTR AND
       HAVE_GETXATTR AND
       HAVE_LGETXATTR AND
       HAVE_LISTXATTR AND
       HAVE_LLISTXATTR AND
       HAVE_LSETXATTR)
      SET(ARCHIVE_XATTR_LINUX TRUE)
    ENDIF()
  ELSEIF(HAVE_SYS_EA_H)
    # AIX xattr support
    CHECK_FUNCTION_EXISTS(fgetea HAVE_FGETEA)
    CHECK_FUNCTION_EXISTS(flistea HAVE_FLISTEA)
    CHECK_FUNCTION_EXISTS(fsetea HAVE_FSETEA)
    CHECK_FUNCTION_EXISTS(getea HAVE_GETEA)
    CHECK_FUNCTION_EXISTS(lgetea HAVE_LGETEA)
    CHECK_FUNCTION_EXISTS(listea HAVE_LISTEA)
    CHECK_FUNCTION_EXISTS(llistea HAVE_LLISTEA)
    CHECK_FUNCTION_EXISTS(lsetea HAVE_LSETEA)
    IF(HAVE_FGETEA AND
       HAVE_FLISTEA AND
       HAVE_FSETEA AND
       HAVE_GETEA AND
       HAVE_LGETEA AND
       HAVE_LISTEA AND
       HAVE_LLISTEA AND
       HAVE_LSETEA)
      SET(ARCHIVE_XATTR_AIX TRUE)
    ENDIF()
  ENDIF()

  IF(ARCHIVE_XATTR_DARWIN)
    MESSAGE(STATUS "Extended attributes support: Darwin")
  ELSEIF(ARCHIVE_XATTR_FREEBSD)
    MESSAGE(STATUS "Extended attributes support: FreeBSD")
  ELSEIF(ARCHIVE_XATTR_LINUX)
    MESSAGE(STATUS "Extended attributes support: Linux")
  ELSEIF(ARCHIVE_XATTR_AIX)
    MESSAGE(STATUS "Extended attributes support: AIX")
  ELSE()
    MESSAGE(STATUS "Extended attributes support: none")
  ENDIF()
ELSE(ENABLE_XATTR)
  SET(ARCHIVE_XATTR_DARWIN FALSE)
  SET(ARCHIVE_XATTR_FREEBSD FALSE)
  SET(ARCHIVE_XATTR_LINUX FALSE)
  SET(ARCHIVE_XATTR_AIX FALSE)
ENDIF(ENABLE_XATTR)

#
# Check for ACL libraries, headers, and functions
#
# The ACL support in libarchive is written against the POSIX1e draft,
# which was never officially approved and varies quite a bit across
# platforms.  Worse, some systems have completely non-POSIX acl functions,
# which makes the following checks rather more complex than I would like.
#
IF(ENABLE_ACL)
  # Solaris and derivates ACLs
  CHECK_FUNCTION_EXISTS(acl HAVE_ACL)
  CHECK_FUNCTION_EXISTS(facl HAVE_FACL)

  # Libacl
  CHECK_LIBRARY_EXISTS(acl "acl_get_file" "" HAVE_LIBACL)
  IF(HAVE_LIBACL)
    SET(CMAKE_REQUIRED_LIBRARIES "acl")
    FIND_LIBRARY(ACL_LIBRARY NAMES acl)
    LIST(APPEND ADDITIONAL_LIBS ${ACL_LIBRARY})
	  pkg_check_modules(LIBACL libacl)
	  IF(LIBACL_VERSION)
	    SET(LIBACL_PKGCONFIG_VERSION ${LIBACL_VERSION})
	  ENDIF(LIBACL_VERSION)
  ELSE(HAVE_LIBACL)
    UNSET(LIBACL_PKGCONFIG_VERSION CACHE)
  ENDIF(HAVE_LIBACL)

  CHECK_TYPE_EXISTS(acl_t "sys/types.h;sys/acl.h" HAVE_ACL_T)
  CHECK_TYPE_EXISTS(acl_entry_t "sys/types.h;sys/acl.h" HAVE_ACL_ENTRY_T)
  CHECK_TYPE_EXISTS(acl_permset_t "sys/types.h;sys/acl.h" HAVE_ACL_PERMSET_T)
  CHECK_TYPE_EXISTS(acl_tag_t "sys/types.h;sys/acl.h" HAVE_ACL_TAG_T)

  IF(HAVE_ACL AND HAVE_FACL)
    CHECK_TYPE_EXISTS(aclent_t "sys/acl.h" HAVE_ACLENT_T)
    IF(HAVE_ACLENT_T)
      CHECK_SYMBOL_EXISTS(GETACL "sys/acl.h" HAVE_DECL_GETACL)
      CHECK_SYMBOL_EXISTS(GETACLCNT "sys/acl.h" HAVE_DECL_GETACLCNT)
      CHECK_SYMBOL_EXISTS(SETACL "sys/acl.h" HAVE_DECL_SETACL)
      IF(HAVE_DECL_GETACL AND
         HAVE_DECL_GETACLCNT AND
         HAVE_DECL_SETACL)
        SET(ARCHIVE_ACL_SUNOS TRUE)
      ENDIF()
      CHECK_TYPE_EXISTS(ace_t "sys/acl.h" HAVE_ACE_T)
      IF(HAVE_ACE_T)
        CHECK_SYMBOL_EXISTS(ACE_GETACL "sys/acl.h" HAVE_DECL_ACE_GETACL)
        CHECK_SYMBOL_EXISTS(ACE_GETACLCNT "sys/acl.h" HAVE_DECL_ACE_GETACLCNT)
        CHECK_SYMBOL_EXISTS(ACE_SETACL "sys/acl.h" HAVE_DECL_ACE_SETACL)
        IF(HAVE_DECL_ACE_GETACL AND
           HAVE_DECL_ACE_GETACLCNT AND
           HAVE_DECL_ACE_SETACL)
          SET(ARCHIVE_ACL_SUNOS_NFS4 TRUE)
        ENDIF()
      ENDIF(HAVE_ACE_T)
    ENDIF(HAVE_ACLENT_T)
  ENDIF(HAVE_ACL AND HAVE_FACL)

  IF(HAVE_ACL_T AND HAVE_ACL_ENTRY_T AND HAVE_ACL_PERMSET_T AND HAVE_ACL_TAG_T)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_add_perm HAVE_ACL_ADD_PERM)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_clear_perms HAVE_ACL_CLEAR_PERMS)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_create_entry HAVE_ACL_CREATE_ENTRY)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_delete_def_file HAVE_ACL_DELETE_DEF_FILE)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_free HAVE_ACL_FREE)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_get_entry HAVE_ACL_GET_ENTRY)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_get_fd HAVE_ACL_GET_FD)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_get_file HAVE_ACL_GET_FILE)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_get_permset HAVE_ACL_GET_PERMSET)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_get_qualifier HAVE_ACL_GET_QUALIFIER)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_get_tag_type HAVE_ACL_GET_TAG_TYPE)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_init HAVE_ACL_INIT)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_set_fd HAVE_ACL_SET_FD)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_set_file HAVE_ACL_SET_FILE)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_set_qualifier HAVE_ACL_SET_QUALIFIER)
    CHECK_FUNCTION_EXISTS_GLIBC(acl_set_tag_type HAVE_ACL_SET_TAG_TYPE)
    IF(HAVE_ACL_ADD_PERM AND
       HAVE_ACL_CLEAR_PERMS AND
       HAVE_ACL_CREATE_ENTRY AND
       HAVE_ACL_DELETE_DEF_FILE AND
       HAVE_ACL_FREE AND
       HAVE_ACL_GET_ENTRY AND
       HAVE_ACL_GET_FD AND
       HAVE_ACL_GET_FILE AND
       HAVE_ACL_GET_PERMSET AND
       HAVE_ACL_GET_QUALIFIER AND
       HAVE_ACL_GET_TAG_TYPE AND
       HAVE_ACL_INIT AND
       HAVE_ACL_SET_FD AND
       HAVE_ACL_SET_FILE AND
       HAVE_ACL_SET_QUALIFIER AND
       HAVE_ACL_SET_TAG_TYPE)
         SET(HAVE_POSIX_ACL_FUNCS 1)
    ENDIF()

    CHECK_FUNCTION_EXISTS_GLIBC(acl_get_perm HAVE_ACL_GET_PERM)

    IF(HAVE_POSIX_ACL_FUNCS AND HAVE_ACL_LIBACL_H AND HAVE_LIBACL AND
       HAVE_ACL_GET_PERM)
      SET(ARCHIVE_ACL_LIBACL TRUE)
    ELSE()
      CHECK_FUNCTION_EXISTS(acl_add_flag_np HAVE_ACL_ADD_FLAG_NP)
      CHECK_FUNCTION_EXISTS(acl_clear_flags_np HAVE_ACL_CLEAR_FLAGS_NP)
      CHECK_FUNCTION_EXISTS(acl_get_brand_np HAVE_ACL_GET_BRAND_NP)
      CHECK_FUNCTION_EXISTS(acl_get_entry_type_np HAVE_ACL_GET_ENTRY_TYPE_NP)
      CHECK_FUNCTION_EXISTS(acl_get_flag_np HAVE_ACL_GET_FLAG_NP)
      CHECK_FUNCTION_EXISTS(acl_get_flagset_np HAVE_ACL_GET_FLAGSET_NP)
      CHECK_FUNCTION_EXISTS(acl_get_fd_np HAVE_ACL_GET_FD_NP)
      CHECK_FUNCTION_EXISTS(acl_get_link_np HAVE_ACL_GET_LINK_NP)
      CHECK_FUNCTION_EXISTS(acl_get_perm_np HAVE_ACL_GET_PERM_NP)
      CHECK_FUNCTION_EXISTS(acl_is_trivial_np HAVE_ACL_IS_TRIVIAL_NP)
      CHECK_FUNCTION_EXISTS(acl_set_entry_type_np HAVE_ACL_SET_ENTRY_TYPE_NP)
      CHECK_FUNCTION_EXISTS(acl_set_fd_np HAVE_ACL_SET_FD_NP)
      CHECK_FUNCTION_EXISTS(acl_set_link_np HAVE_ACL_SET_LINK_NP)
      CHECK_FUNCTION_EXISTS(mbr_gid_to_uuid HAVE_MBR_GID_TO_UUID)
      CHECK_FUNCTION_EXISTS(mbr_uid_to_uuid HAVE_MBR_UID_TO_UUID)
      CHECK_FUNCTION_EXISTS(mbr_uuid_to_id HAVE_MBR_UUID_TO_ID)

      CHECK_C_SOURCE_COMPILES("#include <sys/types.h>
#include <sys/acl.h>
int main(void) { return ACL_TYPE_EXTENDED; }" HAVE_DECL_ACL_TYPE_EXTENDED)
      CHECK_C_SOURCE_COMPILES("#include <sys/types.h>
#include <sys/acl.h>
int main(void) { return ACL_SYNCHRONIZE; }" HAVE_DECL_ACL_SYNCHRONIZE)
      CHECK_SYMBOL_EXISTS(ACL_TYPE_NFS4 "sys/acl.h" HAVE_DECL_ACL_TYPE_NFS4)
      CHECK_SYMBOL_EXISTS(ACL_USER "sys/acl.h" HAVE_DECL_ACL_USER)

      IF(HAVE_POSIX_ACL_FUNCS AND
         HAVE_ACL_GET_FD_NP AND
         HAVE_ACL_GET_PERM_NP AND
         NOT HAVE_ACL_GET_PERM AND
         HAVE_ACL_SET_FD_NP)
        IF(HAVE_DECL_ACL_USER)
          SET(ARCHIVE_ACL_FREEBSD TRUE)
          IF(HAVE_DECL_ACL_TYPE_NFS4 AND
             HAVE_ACL_ADD_FLAG_NP AND
             HAVE_ACL_CLEAR_FLAGS_NP AND
             HAVE_ACL_GET_BRAND_NP AND
             HAVE_ACL_GET_ENTRY_TYPE_NP AND
             HAVE_ACL_GET_FLAGSET_NP AND
             HAVE_ACL_SET_ENTRY_TYPE_NP)
            SET(ARCHIVE_ACL_FREEBSD_NFS4 TRUE)
          ENDIF()
        ELSEIF(HAVE_DECL_ACL_TYPE_EXTENDED AND
               HAVE_MEMBERSHIP_H AND
               HAVE_ACL_ADD_FLAG_NP AND
               HAVE_ACL_CLEAR_FLAGS_NP AND
               HAVE_ACL_GET_FLAGSET_NP AND
               HAVE_ACL_GET_LINK_NP AND
               HAVE_ACL_SET_LINK_NP AND
               HAVE_MBR_UID_TO_UUID AND
               HAVE_MBR_GID_TO_UUID AND
               HAVE_MBR_UUID_TO_ID)
          SET(ARCHIVE_ACL_DARWIN TRUE)
        ENDIF()
      ENDIF()
    ENDIF()
  ENDIF(HAVE_ACL_T AND HAVE_ACL_ENTRY_T AND HAVE_ACL_PERMSET_T AND
        HAVE_ACL_TAG_T)

  # Richacl
  CHECK_LIBRARY_EXISTS(richacl "richacl_get_file" "" HAVE_LIBRICHACL)
  IF(HAVE_LIBRICHACL)
    SET(CMAKE_REQUIRED_LIBRARIES "richacl")
    FIND_LIBRARY(RICHACL_LIBRARY NAMES richacl)
    LIST(APPEND ADDITIONAL_LIBS ${RICHACL_LIBRARY})
	  pkg_check_modules(LIBRICHACL librichacl)
	  IF(LIBRICHACL_VERSION)
	    SET(LIBRICHACL_PKGCONFIG_VERSION ${LIBRICHACL_VERSION})
	  ENDIF(LIBRICHACL_VERSION)
  ELSE(HAVE_LIBRICHACL)
    UNSET(LIBRICHACL_PKGCONFIG_VERSION CACHE)
  ENDIF(HAVE_LIBRICHACL)

  CHECK_STRUCT_HAS_MEMBER("struct richace" e_type "sys/richacl.h"
    HAVE_STRUCT_RICHACE)
  CHECK_STRUCT_HAS_MEMBER("struct richacl" a_flags "sys/richacl.h"
    HAVE_STRUCT_RICHACL)

  IF(HAVE_LIBRICHACL AND HAVE_STRUCT_RICHACL AND HAVE_STRUCT_RICHACE)
    CHECK_FUNCTION_EXISTS_GLIBC(richacl_alloc HAVE_RICHACL_ALLOC)
    CHECK_FUNCTION_EXISTS_GLIBC(richacl_equiv_mode HAVE_RICHACL_EQUIV_MODE)
    CHECK_FUNCTION_EXISTS_GLIBC(richacl_free HAVE_RICHACL_FREE)
    CHECK_FUNCTION_EXISTS_GLIBC(richacl_get_fd HAVE_RICHACL_GET_FD)
    CHECK_FUNCTION_EXISTS_GLIBC(richacl_get_file HAVE_RICHACL_GET_FILE)
    CHECK_FUNCTION_EXISTS_GLIBC(richacl_set_fd HAVE_RICHACL_SET_FD)
    CHECK_FUNCTION_EXISTS_GLIBC(richacl_set_file HAVE_RICHACL_SET_FILE)
    IF(HAVE_RICHACL_ALLOC AND
       HAVE_RICHACL_EQUIV_MODE AND
       HAVE_RICHACL_FREE AND
       HAVE_RICHACL_GET_FD AND
       HAVE_RICHACL_GET_FILE AND
       HAVE_RICHACL_SET_FD AND
       HAVE_RICHACL_SET_FILE)
      SET(ARCHIVE_ACL_LIBRICHACL TRUE)
    ENDIF()
  ENDIF(HAVE_LIBRICHACL AND HAVE_STRUCT_RICHACL AND HAVE_STRUCT_RICHACE)

  IF(ARCHIVE_ACL_DARWIN)
    MESSAGE(STATUS "ACL support: Darwin (limited NFSv4)")
  ELSEIF(ARCHIVE_ACL_FREEBSD_NFS4)
    MESSAGE(STATUS "ACL support: FreeBSD (POSIX.1e and NFSv4)")
  ELSEIF(ARCHIVE_ACL_FREEBSD)
    MESSAGE(STATUS "ACL support: FreeBSD (POSIX.1e)")
  ELSEIF(ARCHIVE_ACL_LIBACL OR ARCHIVE_ACL_LIBRICHACL)
    IF(ARCHIVE_ACL_LIBACL AND ARCHIVE_ACL_LIBRICHACL)
      MESSAGE(STATUS "ACL support: libacl (POSIX.1e) + librichacl (NFSv4)")
    ELSEIF(ARCHIVE_ACL_LIBRICHACL)
      MESSAGE(STATUS "ACL support: librichacl (NFSv4)")
    ELSE()
      MESSAGE(STATUS "ACL support: libacl (POSIX.1e)")
    ENDIF()
  ELSEIF(ARCHIVE_ACL_SUNOS_NFS4)
    MESSAGE(STATUS "ACL support: Solaris (POSIX.1e and NFSv4)")
  ELSEIF(ARCHIVE_ACL_SUNOS)
    MESSAGE(STATUS "ACL support: Solaris (POSIX.1e)")
  ELSE()
    MESSAGE(STATUS "ACL support: none")
  ENDIF()

ELSE(ENABLE_ACL)
  # If someone runs cmake, then disables ACL support, we need
  # to forcibly override the cached values for these.
  SET(ARCHIVE_ACL_DARWIN FALSE)
  SET(ARCHIVE_ACL_FREEBSD FALSE)
  SET(ARCHIVE_ACL_FREEBSD_NFS4 FALSE)
  SET(ARCHIVE_ACL_LIBACL FALSE)
  SET(ARCHIVE_ACL_SUNOS FALSE)
  SET(ARCHIVE_ACL_SUNOS_NFS4 FALSE)
ENDIF(ENABLE_ACL)

#
# Check MD5/RMD160/SHA support
# NOTE: Crypto checks must be run last before generating config.h
#
IF(CMAKE_SYSTEM_NAME MATCHES "Darwin")
  CHECK_CRYPTO("MD5;SHA1;SHA256;SHA384;SHA512" LIBSYSTEM)
ELSE()
  CHECK_CRYPTO("MD5;RMD160;SHA1;SHA256;SHA384;SHA512" LIBC)
  CHECK_CRYPTO("SHA256;SHA384;SHA512" LIBC2)
  CHECK_CRYPTO("SHA256;SHA384;SHA512" LIBC3)
  CHECK_CRYPTO("MD5;RMD160;SHA1;SHA256;SHA384;SHA512" MBEDTLS)
  CHECK_CRYPTO("MD5;RMD160;SHA1;SHA256;SHA384;SHA512" NETTLE)
  CHECK_CRYPTO("MD5;RMD160;SHA1;SHA256;SHA384;SHA512" OPENSSL)

  # Libmd has to be probed after OpenSSL.
  CHECK_CRYPTO("MD5;RMD160;SHA1;SHA256;SHA512" LIBMD)
ENDIF()

# Check visibility annotations
SET(OLD_CMAKE_REQUIRED_FLAGS "${CMAKE_REQUIRED_FLAGS}")
SET(CMAKE_REQUIRED_FLAGS "${CMAKE_REQUIRED_FLAGS} -fvisibility=hidden -Werror")
CHECK_C_SOURCE_COMPILES("void __attribute__((visibility(\"default\"))) foo(void);
int main() { return 0; }" HAVE_VISIBILITY_ATTR)
IF (HAVE_VISIBILITY_ATTR)
  SET(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -fvisibility=hidden")
  ADD_DEFINITIONS(-D__LIBARCHIVE_ENABLE_VISIBILITY)
ENDIF(HAVE_VISIBILITY_ATTR)
SET(CMAKE_REQUIRED_FLAGS "${OLD_CMAKE_REQUIRED_FLAGS}")

# Generate "config.h" from "build/cmake/config.h.in"
CONFIGURE_FILE(${CMAKE_CURRENT_SOURCE_DIR}/build/cmake/config.h.in
	${CMAKE_CURRENT_BINARY_DIR}/config.h)
INCLUDE_DIRECTORIES(BEFORE ${CMAKE_CURRENT_BINARY_DIR})
ADD_DEFINITIONS(-DHAVE_CONFIG_H)

# Handle generation of the libarchive.pc file for pkg-config
INCLUDE(CreatePkgConfigFile)

#
# Register installation of PDF documents.
#
IF(WIN32 AND NOT CYGWIN AND ENABLE_INSTALL)
  #
  # On Windows platform, It's better that we install PDF documents
  # on one's computer.
  # These PDF documents are available in the release package.
  #
  IF(EXISTS ${CMAKE_CURRENT_SOURCE_DIR}/doc/pdf)
    INSTALL(DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/doc/pdf
            DESTINATION share/man
            FILES_MATCHING PATTERN "*.pdf"
    )
  ENDIF(EXISTS ${CMAKE_CURRENT_SOURCE_DIR}/doc/pdf)
ENDIF(WIN32 AND NOT CYGWIN AND ENABLE_INSTALL)
#
#
#
INCLUDE_DIRECTORIES(BEFORE ${CMAKE_CURRENT_SOURCE_DIR}/libarchive)
#
IF(MSVC)
  ADD_DEFINITIONS(
    -D_CRT_NONSTDC_NO_WARNINGS
    -D_CRT_SECURE_NO_DEPRECATE
  )
ENDIF(MSVC)

OPTION(DONT_FAIL_ON_CRC_ERROR "Ignore CRC errors during parsing (For fuzzing)" OFF)
IF(DONT_FAIL_ON_CRC_ERROR)
  ADD_DEFINITIONS(-DDONT_FAIL_ON_CRC_ERROR=1)
ENDIF(DONT_FAIL_ON_CRC_ERROR)

IF(ENABLE_TEST)
  ADD_CUSTOM_TARGET(run_all_tests)
ENDIF(ENABLE_TEST)

IF(ENABLE_CLANG_TIDY)
  IF(NOT CLANG_TIDY_PATH)
    SET(CLANG_TIDY_PATH clang-tidy)
  ENDIF(NOT CLANG_TIDY_PATH)
  SET(CMAKE_C_CLANG_TIDY ${CLANG_TIDY_PATH})
ENDIF(ENABLE_CLANG_TIDY)

add_subdirectory(libarchive)
add_subdirectory(cat)
add_subdirectory(tar)
add_subdirectory(cpio)
add_subdirectory(unzip)
